# The Operator Toolkit

Companion files for *The Claude Operator*. Everything here is referenced in the book.

## What's inside

| Folder or file | What it holds | Book |
|---|---|---|
| `install-ready/` | Every skill as a .zip file, ready to upload to Claude | Every Skill Drop |
| `skills/` | The same 32 skills as readable folders: `SKILL.md`, a five-input `tests.md`, and placeholder reference files to replace with your own | Every Skill Drop |
| `role-packs/` | Five Role Packs: a README with the role's setup, and the role's own skill | Ch. 21 |
| `50-Claude-Workflows-for-Professionals.pdf` | Ten ready-to-run workflows each for research, marketing, operations, finance and management | Whole book |
| `posters/` | The Operator Loop and the Three Questions, one page each | Ch. 2–3 |
| `templates/Briefing-Pack-Template.docx` | Your one-page briefing pack, with the diagnosis table | Ch. 4 |
| `templates/Delegation-Brief-Template.docx` | The eight-part brief, a worked example, the five-minute review and the five patterns | Ch. 2, 5 |
| `templates/Design-Brief-and-Brand-System-Worksheet.pdf` | Brand system set-up, voice, house style, four design briefs and the finish line | Ch. 14, 16 |
| `templates/Project-Rulebook-and-Automation-Recipes.pdf` | A starter CLAUDE.md for non-developers, plus ten automation recipes | Ch. 9, 17, 18 |
| `templates/Team-AI-Use-Policy-Template.docx` | A one-page AI-use policy for your team | Ch. 22 |
| `templates/30-Day-Operator-Plan-Tracker.pdf` | The 30-day plan as a printable tracker | Ch. 23 |
| `workbooks/Chief-of-Staff-Ledger-and-ROI-Scorecards.xlsx` | Your Ledger, all five capstone scorecards, the ROI Ledger and skill measures | Ch. 1 onwards |
| `workbooks/Skill-Test-Sheet-and-Versioning-Log.xlsx` | Test sheet, change log and owner register | Ch. 8 |
| `workbooks/Monthly-Review-Workbook-Template.xlsx` | The six-tab review workbook with a working Checks tab | Ch. 13 |
| `practice-files/` | Three practice workbooks for Part 3, a guide, and a separate answer key | Ch. 11–13 |

## Installing a skill

1. Make sure code execution and file creation are switched on in your Claude settings. Skills need them to work.
2. Open the Skills section of your Claude settings. The exact menu path can change, so check the update page if you can't find it.
3. Upload the skill's .zip file from `install-ready/`.
4. Before relying on it, run its tests: open `tests.md` and run each of the five inputs in a fresh conversation (Chapter 8). Or use the Skill Test Harness skill to do it for you.

On a Team or Enterprise plan, an owner can provision skills to the whole organisation instead (Chapter 22).

**Customise before you trust.** Several skills refer to your own files, such as `briefing-pack.md`, your brand system or your review workbook. Each skill works best once those exist. Build them in the chapter where the skill is introduced.

## The Skills Library


### Part 1: Hire Your Chief of Staff

| # | Skill | Chapter | When it's used |
|---|---|---|---|
| 1 | `operator-self-assessment` | 1 | Place me on the five-level Operator Scale and recommend my next three moves. Use when I ask for my operator level, a Claude maturity check, or what to automate next. |
| 2 | `operator-check` | 2 | Run the six-question Operator Check on a result before I trust or send it. Use when I say "check this", "operator check", or ask whether a draft, report or analysis is safe to use. |
| 3 | `task-router` | 3 | Route a task with the three questions and turn it into a ready-to-run brief. Use when I describe a task loosely, say "route this", or ask how to hand it to Claude. |
| 4 | `about-me-and-my-work` | 4 | My briefing pack: who I am, where my work lives, what our terms mean, how I decide, my limits. Use at the start of any delegated or multi-step job for me. |

### Part 2: Delegate, Package, Automate

| # | Skill | Chapter | When it's used |
|---|---|---|---|
| 5 | `delegation-brief` | 5 | Turn a short job description into a full eight-part delegation brief. Use when I say "brief this", ask for a delegation brief, or describe a job to hand over. |
| 6 | `inbox-triage` | 6 | Turn my recent email and calendar into one prioritised action list, with draft replies saved but never sent. Use when I say "triage my inbox", "what's waiting on me", or ask what needs my attention. |
| 7 | `meeting-brief` | 7 | Prepare a one-page brief for an upcoming meeting from my calendar, email and files. Use when I ask to prep for a meeting or want briefs for tomorrow's meetings. |
| 8 | `research` | 7 | Research a question from sources I trust and return a sourced summary with confidence levels. Use when I ask to research, look into, or find out about a topic. |
| 9 | `weekly-report` | 7 | Draft my weekly update from this week's notes, tracker and sent email. Use when I ask for my weekly update, status report or Friday update. |
| 10 | `brand-voice` | 7 | Rewrite or check text in our brand voice using the guide and examples in this skill. Use when I ask to make something sound like us or check brand voice. |
| 11 | `spreadsheet-audit` | 7 | Audit a spreadsheet for broken formulas, hard-coded numbers and inconsistencies, and explain its logic. Use when I share a workbook to check or understand. |
| 12 | `competitor-watch` | 7 | Check named competitors for changes in pricing, products, hiring and news since the last check. Use when I ask what competitors are doing or for a competitor update. |
| 13 | `proposal` | 7 | Draft a client proposal from my notes using our template and past winning proposals. Use when I ask for a proposal, pitch document or statement of work. |
| 14 | `skill-test-harness` | 8 | Test one of my skills: write or load its five-input test set, run each input, and fill in a pass/fail sheet. Use when I say "test [skill]" or after I change a skill. |
| 15 | `scheduled-monitor` | 9 | Check named sources for changes since the last run and report only what changed, with a status line. Use for scheduled monitoring or when I ask to watch something for changes. |
| 16 | `post-mortem` | 10 | Diagnose a delegation failure against the eight known types and produce a rule, a brief fix and a new test input. Use when I say "that went wrong", "post-mortem" or describe a bad result. |
| 17 | `executive-brief` | 10 (Capstone 1) | Produce my Monday executive brief from email, calendar, project files and last week's brief. Use for the scheduled Monday brief or when I ask for my weekly brief. |

### Part 3: Analyse and Decide

| # | Skill | Chapter | When it's used |
|---|---|---|---|
| 18 | `formula-explainer` | 11 | Explain how one spreadsheet cell is calculated in plain English, trace it to its inputs with cell citations, and flag risks. Use when I ask how a number is worked out. |
| 19 | `assumption-checker` | 12 | Find every assumption in a forecast or model, stated or hidden, and rate how well each is sourced and tested. Use when I ask to check a forecast or prepare to defend one. |
| 20 | `variance-commentary` | 13 | Turn a variance table into the three findings that matter, each as what, why, so what, now what, with data-backed causes. Use for monthly reviews and performance commentary. |
| 21 | `monthly-review` | 13 (Capstone 2) | Runs my Monthly Business Review: clean, reconcile, flag, find variances, then build a six-slide deck with cell sources. Stops if the numbers don't reconcile. Use at month-end. |

### Part 4: Create and Communicate

| # | Skill | Chapter | When it's used |
|---|---|---|---|
| 22 | `house-style-editor` | 14 | Edit a document to our house style, one pass at a time (structure, tighten, tone), keeping every fact. Use when I ask to edit, tighten or house-style a document. |
| 23 | `deck-storyliner` | 15 | Turn material into a headline-title deck outline for my approval, then build slides only once I approve. Use when I ask for a deck, presentation or slides. |
| 24 | `brand-system` | 16 | Brief and check visual work (landing pages, one-pagers, social posts, prototypes) against our brand, voice and honesty rules. Use when I ask for any visual or launch material. |
| 25 | `launch-kit` | 16 (Capstone 3) | Runs a launch for an idea: research, positioning, landing page, deck and social set, then an audience test before anything goes live. Use when I say "run the launch kit". |

### Part 5: Build

| # | Skill | Chapter | When it's used |
|---|---|---|---|
| 26 | `safe-setup` | 17 | Set up a new Claude Code project safely: dedicated folder, starter CLAUDE.md, Git save points, inputs protected. Use when I start a new building project or say "set this up safely". |
| 27 | `file-tidy` | 18 | Tidies a messy folder safely: plans renames and moves as a dry run, waits for approval, never deletes, and logs every change so it can be undone. Use when asked to organise or clean up files. |
| 28 | `tool-spec-writer` | 19 | Turns a rough idea for an internal tool into a one-page build spec: job, users, screens, data, rules and done-means. Use before asking Claude to build any tool or app. |
| 29 | `change-reviewer` | 20 | Reviews a proposed change to a shared tool before it is accepted: what changed, what else depends on it, which tests to run, and how to roll back. Use before accepting any change. |

### Part 6: Switch On Your Chief of Staff

| # | Skill | Chapter | When it's used |
|---|---|---|---|
| 30 | `role-setup` | 21 | Designs my Chief of Staff setup: work chain, five modules, skills, schedule and what stays by hand. Use when I ask to set up my role or adapt a Role Pack. |
| 31 | `roi-ledger` | 22 | Builds my monthly ROI Ledger from scorecards and job logs: net hours, quality, cost and a return ratio, flagging estimates. Use at month start or when asked about ROI. |
| 32 | `weekly-operator-review` | 23 | Runs my 15-minute Friday review: what ran, what failed, what I did not read, skills to re-test, and one decision per workflow (grow, keep, fix or retire). Use at the end of each week. |

## Role Packs

| Role Pack | Role skill | When it's used |
|---|---|---|
| Consultant | `client-follow-up` | Turns meeting notes into a client follow-up: summary, decisions, next steps with owners, and a draft email in the client's terms. Use after any client meeting. |
| Marketing Manager | `campaign-readout` | Turns a campaign's results into what worked, what didn't and what to change, with every claim tied to a number. Use when a campaign ends or I ask for a readout. |
| Founder | `investor-update` | Drafts my monthly investor update from the month's numbers and decisions, stating what went wrong as plainly as what went right. Use at month-end or when asked. |
| Operations Manager | `sop-writer` | Turns a walkthrough, recording or email thread into a numbered SOP with an owner, a trigger and a what-if-it-goes-wrong step. Use when I ask to document a process. |
| Finance Lead | `reconciliation-check` | Compares two exports (e.g. bank and ledger), lists every mismatch with its likely cause, and never marks anything resolved. Use for reconciliations during close. |

Install your own pack's role skill, plus Role Setup. That's the 33rd skill in your library.

## Keeping skills current

- Re-run a skill's tests after every Claude model update, after you change the skill, and once a quarter (Chapter 8).
- Add a line to the change log in `tests.md` every time you edit a skill.
- Keep the previous version's .zip so you can roll back in two minutes.

*Toolkit version 1.1 · Last verified 30 September 2026*
