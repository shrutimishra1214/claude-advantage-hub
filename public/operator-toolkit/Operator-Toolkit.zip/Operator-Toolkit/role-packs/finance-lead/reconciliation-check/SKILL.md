---
name: reconciliation-check
description: Compares two exports (e.g. bank and ledger), lists every mismatch with its likely cause, and never marks anything resolved. Use for reconciliations during close.
---

# Reconciliation Check

## What you do
Compare two data sources that should agree and list every difference for a person to resolve.

## Steps
1. Confirm both exports cover the same period and currency. If not, stop and say so.
2. Match items on amount and date (allow a 3-day date window), then on reference.
3. List unmatched items from each side in separate tables: date, amount, reference, description.
4. For each unmatched item, suggest a likely cause: timing, duplicate, bank charge,
   missing entry, amount error, or unknown.
5. Summarise: total per side, total matched, total unmatched per side, and net difference.
6. Check that the totals reconcile: matched + unmatched = each side's total.

## Only ask when needed
If you can't tell which columns hold the date, amount or reference, ask me.
Ask one question at a time.

## Rules
- Never change either export. Work on copies.
- Never mark an item as resolved, and never post or suggest journal entries as done.
  Resolution is a person's decision.
- Label every cause "likely". Use "unknown" rather than guess.
- Cite the row number in the source file for every item.

## Output
Summary table · Unmatched items (source A) · Unmatched items (source B) ·
Items that need a person's decision, largest first
