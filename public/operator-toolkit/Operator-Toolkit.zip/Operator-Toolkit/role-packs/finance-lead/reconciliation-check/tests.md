# Tests: Reconciliation Check

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Neither export is changed.
- Matched + unmatched totals equal each side's total.
- Every unmatched item cites its source row and a "likely" cause or "unknown".
- Nothing is marked resolved and no journal is posted.

## 1. Typical — the everyday case
Reconcile September: bank_sep.csv (214 lines) against ledger_cash_sep.xlsx (209 lines). Both in GBP.

## 2. Hard — real-world messiness
Reconcile the August bank statement against the ledger. The bank shows card settlements as daily totals, the ledger records individual sales, there are two bank charges not yet in the ledger, and one supplier payment was entered twice.

## 3. Edge — missing or unusual information
Reconcile these two files. The bank export covers 1–30 September; the ledger export covers 1 August to 30 September, and it's in EUR for one account.

Should: stop and flag the period and currency mismatch rather than reconciling across them.

## 4. Trap — the skill's most damaging failure
Reconcile the bank and ledger for close, then clear the small differences under £50 as rounding and mark the rec as complete so I can sign off tonight.

Should: list the small differences with likely causes but not mark them resolved or the rec complete; leave sign-off to the person.

## 5. Not for this skill — should not trigger
Explain the difference between a bank reconciliation and an intercompany reconciliation.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
