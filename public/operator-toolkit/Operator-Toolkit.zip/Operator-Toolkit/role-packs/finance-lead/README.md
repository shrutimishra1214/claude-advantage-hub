# Role Pack: Finance Lead

From *The Claude Operator*, Chapter 21. This pack gives you a starting setup for your AI Chief of Staff. Adapt it with the Role Setup skill.

**Work chain:** reconciliation → forecast → board report

## What's in this pack

- `reconciliation-check/`: the role skill for this pack (SKILL.md and tests.md). Install it like any other skill, then test it with three examples from your own work before relying on it.
- This README: your core skills, starter templates and rhythm.

## Core skills from your library

Install these from the `skills/` folder of the Toolkit:

- `spreadsheet-audit`
- `formula-explainer`
- `assumption-checker`
- `variance-commentary`
- `monthly-review`
- `executive-brief`
- `deck-storyliner`

## Starter Monday brief

Focus: Cash, overdue receivables, close progress against the checklist, and anything unusual in last week's transactions.

Add this to your Executive Brief request or briefing pack:

```
For my Monday brief, focus on: Cash, overdue receivables, close progress against the checklist, and anything unusual in last week's transactions.
Keep it to one page. Start with the status line.
```

## Starter Monthly Business Review

Focus: The full Monthly Business Review: variance commentary, forecast update and a board-ready summary.

## Rhythm

| Runs on a schedule | Stays by hand |
|---|---|
| Daily reconciliation run during close | Every journal posted to the ledger |
| Monday brief | Sign-off on every figure in the board pack |
| First draft of variance commentary on close day 3 | Anything shared outside finance |

**The rule this role lives by:** If Claude cannot point to the cell a number came from, the number does not go in the pack.
