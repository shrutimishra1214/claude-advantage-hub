# Role Pack: Marketing Manager

From *The Claude Operator*, Chapter 21. This pack gives you a starting setup for your AI Chief of Staff. Adapt it with the Role Setup skill.

**Work chain:** competitor research → campaign → creative → performance report

## What's in this pack

- `campaign-readout/`: the role skill for this pack (SKILL.md and tests.md). Install it like any other skill, then test it with three examples from your own work before relying on it.
- This README: your core skills, starter templates and rhythm.

## Core skills from your library

Install these from the `skills/` folder of the Toolkit:

- `competitor-watch`
- `brand-voice`
- `brand-system`
- `launch-kit`
- `house-style-editor`
- `variance-commentary`
- `deck-storyliner`

## Starter Monday brief

Focus: Last week's key numbers against target, competitor moves, and this week's launches.

Add this to your Executive Brief request or briefing pack:

```
For my Monday brief, focus on: Last week's key numbers against target, competitor moves, and this week's launches.
Keep it to one page. Start with the status line.
```

## Starter Monthly Business Review

Focus: The monthly performance report, with variance commentary on every channel.

## Rhythm

| Runs on a schedule | Stays by hand |
|---|---|
| Competitor Watch (Monday) | Final approval of anything published |
| Monday brief with last week's numbers | Budget decisions |
| First draft of the monthly performance report | Anything that mentions a customer by name |

**The rule this role lives by:** Publishing is never automated. A person presses the button, every time.
