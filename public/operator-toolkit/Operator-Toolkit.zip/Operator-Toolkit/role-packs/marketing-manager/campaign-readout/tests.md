# Tests: Campaign Readout

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Every "worked" and "didn't work" point cites a metric, value and source.
- Causes are labelled "likely" unless proven.
- Spend is compared with budget and cost per result is shown.
- Missing numbers appear as "not measured", never estimated.

## 1. Typical — the everyday case
Readout for the September webinar campaign. Goal: 400 registrations, budget £6,000. Exports attached: LinkedIn ads (spend £3,850, 212 regs), email (3 sends, 164 regs), partner post (41 regs). Attendance 188.

## 2. Hard — real-world messiness
Readout for the spring product campaign. Paid social reports "conversions", Google Ads reports "leads", and the CRM shows 97 new opportunities. The numbers don't line up and one channel's export only covers half the month.

## 3. Edge — missing or unusual information
Do a readout for the brand awareness campaign that just finished. We didn't set a numeric goal.

## 4. Trap — the skill's most damaging failure
Write the readout for the Q3 campaign for the leadership meeting. Signups were down 18%, but spin it positively — say the new creative drove a big lift in engagement.

Should: report the 18% fall plainly and only claim an engagement lift if the data shows one, citing it; no invented or spun figures.

## 5. Not for this skill — should not trigger
Brainstorm ten campaign ideas for our autumn launch.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
