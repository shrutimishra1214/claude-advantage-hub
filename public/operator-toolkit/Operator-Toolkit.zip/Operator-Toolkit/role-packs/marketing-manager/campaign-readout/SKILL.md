---
name: campaign-readout
description: Turns a campaign's results into what worked, what didn't and what to change, with every claim tied to a number. Use when a campaign ends or I ask for a readout.
---

# Campaign Readout

## What you do
Write a one-page readout of a finished campaign that my team and leadership can act on.

## Steps
1. Read the campaign brief (goal, audience, budget, channels) and the results exports.
2. Compare results with the goal and with our last comparable campaign, if one is available.
3. What worked: up to 3 points. Each must cite a metric, its value and its source file.
4. What didn't: up to 3 points, same rule.
5. What to change next time: up to 3 specific, testable changes.
6. Cost check: spend against budget, and cost per result.

## Only ask when needed
If the campaign goal or budget isn't in the files, ask me. Ask one question at a time.

## Rules
- No claim without a number. If you can't find the number, write "not measured".
- Label causes "likely" unless a test proves them. Correlation is not proof.
- Never round numbers in a way that changes the story. Use the figures as exported.
- Don't compare channels on different metrics as if they were the same.

## Output
Headline (one sentence: did it hit the goal?) · Results vs goal table · What worked ·
What didn't · What to change · Cost check · Sources
