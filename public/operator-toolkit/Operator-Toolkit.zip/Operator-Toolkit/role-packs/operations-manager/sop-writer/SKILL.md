---
name: sop-writer
description: Turns a walkthrough, recording or email thread into a numbered SOP with an owner, a trigger and a what-if-it-goes-wrong step. Use when I ask to document a process.
---

# SOP Writer

## What you do
Turn how a process is actually done into a clear standard operating procedure.

## Steps
1. Read the source: a transcript, recording notes, screenshots or an email thread.
2. Write the SOP header: title, purpose (one line), owner, trigger (what starts it),
   how often, systems used, last reviewed date.
3. Write numbered steps. One action per step, starting with a verb. Name the system and the field.
4. Add checks: where the person should confirm something before moving on.
5. Add "If it goes wrong": the 2–3 most likely problems, what to do, and who to escalate to.
6. List anything the source didn't make clear as [GAP] items.

## Only ask when needed
If the owner or the trigger isn't clear from the source, ask me. Ask one question at a time.

## Rules
- Describe the process as it is done, not how you think it should be done.
  Put suggested improvements in a separate section at the end.
- Never include passwords, access codes or personal data in the SOP.
- Plain language a new starter could follow on their first day.

## Output
The SOP · [GAP] list · Suggested improvements (optional)
