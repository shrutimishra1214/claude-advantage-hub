# Role Pack: Operations Manager

From *The Claude Operator*, Chapter 21. This pack gives you a starting setup for your AI Chief of Staff. Adapt it with the Role Setup skill.

**Work chain:** inbox → tasks → SOP → dashboard → recurring report

## What's in this pack

- `sop-writer/`: the role skill for this pack (SKILL.md and tests.md). Install it like any other skill, then test it with three examples from your own work before relying on it.
- This README: your core skills, starter templates and rhythm.

## Core skills from your library

Install these from the `skills/` folder of the Toolkit:

- `inbox-triage`
- `delegation-brief`
- `weekly-report`
- `scheduled-monitor`
- `spreadsheet-audit`
- `file-tidy`
- `tool-spec-writer`

## Starter Monday brief

Focus: Overnight exceptions, overdue tasks by team lead, and supplier issues, drawn from inbox and tracker.

Add this to your Executive Brief request or briefing pack:

```
For my Monday brief, focus on: Overnight exceptions, overdue tasks by team lead, and supplier issues, drawn from inbox and tracker.
Keep it to one page. Start with the status line.
```

## Starter Monthly Business Review

Focus: Service levels, cost per unit and incident trends, with commentary on anything off target.

## Rhythm

| Runs on a schedule | Stays by hand |
|---|---|
| Inbox Triage (twice a day) | Escalations to customers |
| Monday brief (Monday, 6:30) | Supplier penalties or contract changes |
| Weekly data merge and report | Anything involving an individual's performance |

**The rule this role lives by:** Start with the report you hate most.
