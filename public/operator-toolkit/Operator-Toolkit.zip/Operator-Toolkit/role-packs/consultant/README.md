# Role Pack: Consultant

From *The Claude Operator*, Chapter 21. This pack gives you a starting setup for your AI Chief of Staff. Adapt it with the Role Setup skill.

**Work chain:** research → analysis → client deck → follow-up

## What's in this pack

- `client-follow-up/`: the role skill for this pack (SKILL.md and tests.md). Install it like any other skill, then test it with three examples from your own work before relying on it.
- This README: your core skills, starter templates and rhythm.

## Core skills from your library

Install these from the `skills/` folder of the Toolkit:

- `research`
- `meeting-brief`
- `proposal`
- `deck-storyliner`
- `executive-brief`
- `brand-voice`

## Starter Monday brief

Focus: Every deadline across all clients on one page, plus anything a client sent over the weekend.

Add this to your Executive Brief request or briefing pack:

```
For my Monday brief, focus on: Every deadline across all clients on one page, plus anything a client sent over the weekend.
Keep it to one page. Start with the status line.
```

## Starter Monthly Business Review

Focus: Your own practice: utilisation, pipeline, invoices outstanding.

## Rhythm

| Runs on a schedule | Stays by hand |
|---|---|
| Monday brief (Monday, 7:00) | The recommendation in every deck |
| Competitor Watch for each client's market (weekly) | Pricing and scope in proposals |
| Month-end practice review | Anything a client will read, before it is sent |

**The rule this role lives by:** Keep one Project per client and never mix them.
