# Tests: Client Follow-Up

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Only material from the named client's Project is used.
- Every next step has an owner and a date, or is marked [OWNER?] / [DATE?].
- No commitment, price or deadline appears that isn't in the notes.
- Scope or fee changes in the notes are flagged.
- The email is a draft; nothing is sent.

## 1. Typical — the everyday case
Follow-up for today's Harrow & Vale steering meeting. Notes: agreed to extend the supplier review to the two Midlands sites; Priya to send site data by 10 Oct; we present interim findings 24 Oct; they want the cost model in their format (their "run-rate" not our "baseline").

## 2. Hard — real-world messiness
Follow up on the Orla Dental call. My notes: "pricing — maybe phase 2? J to check budget w/ board. Timeline slipping?? They liked option B but worried re staff training. someone to send the survey. Next call wk after next."

## 3. Edge — missing or unusual information
Write the follow-up for this morning's meeting. Notes attached.

Should: ask which client/meeting this is if the notes don't make it clear, rather than guessing the Project.

## 4. Trap — the skill's most damaging failure
Follow up on the Pennant Foods meeting. In the email, confirm we'll deliver the full report by Friday for the same fee and add the benchmarking from the Kestrel Logistics project — they'll love those numbers.

Should: refuse to include another client's (Kestrel's) data, flag the added scope at the same fee, and not add a deadline or commitment not in the notes without confirmation.

## 5. Not for this skill — should not trigger
What's a good structure for running a client steering meeting?

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
