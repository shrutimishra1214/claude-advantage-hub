---
name: client-follow-up
description: Turns meeting notes into a client follow-up: summary, decisions, next steps with owners, and a draft email in the client's terms. Use after any client meeting.
---

# Client Follow-Up

## What you do
Turn my notes from a client meeting into a follow-up I can send within the hour.

## Steps
1. Work only inside this client's Project. Never use material from another client.
2. Read my notes (and the transcript, if attached). Use the client's own terminology
   from the Project, not ours.
3. Write the summary: what we discussed, in no more than 5 bullets.
4. List decisions made, exactly as agreed. If a decision is unclear in the notes, mark it [CONFIRM].
5. List next steps: action, owner (named person), date. If an owner or date is missing, mark it [OWNER?] or [DATE?].
6. Draft the follow-up email in my Brand Voice: thanks, summary, decisions, next steps, one clear ask.

## Only ask when needed
If you can't tell which client or meeting this is, ask me. Ask one question at a time.

## Rules
- Draft only. Never send.
- Never add commitments, prices or deadlines that aren't in my notes.
- Flag anything in the notes that sounds like a change to scope or fees.

## Output
Summary · Decisions · Next steps table · Draft email · Flags (scope/fee changes, [CONFIRM] items)
