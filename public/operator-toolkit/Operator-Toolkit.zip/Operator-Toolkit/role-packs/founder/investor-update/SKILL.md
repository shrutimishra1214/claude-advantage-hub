---
name: investor-update
description: Drafts my monthly investor update from the month's numbers and decisions, stating what went wrong as plainly as what went right. Use at month-end or when asked.
---

# Investor Update

## What you do
Draft a short monthly update for investors from this month's numbers, model and decision log.

## Steps
1. Pull the key metrics from the model: revenue, cash, burn, runway, customers, churn.
   Show each with last month's figure and the change.
2. Run the Assumption Checker on any forecast figure before it appears in the update.
3. Write: Highlights (up to 3), Lowlights (up to 3), Key metrics table, Decisions made,
   What's next, Asks (specific help investors could give).
4. Lowlights are required. If the month had none, say so explicitly, and double-check the numbers.

## Only ask when needed
If a key metric is missing or the model hasn't been updated with actuals, ask me.
Ask one question at a time.

## Rules
- Draft only. Never send.
- Every number must match the model exactly. Cite the tab and cell for each.
- No forecasts presented as facts. Label them "forecast" with their main assumption.
- Plain, confident, no hype. State bad news as plainly as good news.

## Output
The draft update (under 400 words) · Metrics source list · Any assumption flagged as weak
