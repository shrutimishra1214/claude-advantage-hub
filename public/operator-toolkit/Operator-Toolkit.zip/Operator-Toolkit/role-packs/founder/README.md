# Role Pack: Founder

From *The Claude Operator*, Chapter 21. This pack gives you a starting setup for your AI Chief of Staff. Adapt it with the Role Setup skill.

**Work chain:** market research → financial model → landing page → prototype

## What's in this pack

- `investor-update/`: the role skill for this pack (SKILL.md and tests.md). Install it like any other skill, then test it with three examples from your own work before relying on it.
- This README: your core skills, starter templates and rhythm.

## Core skills from your library

Install these from the `skills/` folder of the Toolkit:

- `research`
- `competitor-watch`
- `assumption-checker`
- `formula-explainer`
- `brand-system`
- `tool-spec-writer`
- `change-reviewer`
- `executive-brief`

## Starter Monday brief

Focus: Cash position, sign-ups and cancellations, open customer issues, and the week's three priorities.

Add this to your Executive Brief request or briefing pack:

```
For my Monday brief, focus on: Cash position, sign-ups and cancellations, open customer issues, and the week's three priorities.
Keep it to one page. Start with the status line.
```

## Starter Monthly Business Review

Focus: The financial model updated with actuals, its assumptions checked, and the investor update drafted.

## Rhythm

| Runs on a schedule | Stays by hand |
|---|---|
| Monday brief (Sunday evening) | Pricing changes |
| Competitor Watch (weekly) | Anything sent to investors |
| Monthly model refresh and Assumption Checker | Hiring and contract decisions |

**The rule this role lives by:** Run the Assumption Checker before every investor conversation.
