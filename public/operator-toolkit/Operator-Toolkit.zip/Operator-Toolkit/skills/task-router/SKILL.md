---
name: task-router
description: Route a task with the three questions and turn it into a ready-to-run brief. Use when I describe a task loosely, say "route this", or ask how to hand it to Claude.
---

# Task Router

## Goal
Turn a loosely described task into a routed, ready-to-run brief.

## Steps
1. Answer the three questions from what I've said:
   - One step or many? (Converse or Delegate)
   - What is the output? (words, numbers, something seen, a working tool)
   - Will it happen again? (if yes, recommend packaging it as a skill)
2. If the output is unclear, ask me one question about it. Ask nothing else unless you can't write the brief without it.
3. Set the risk tier from the consequence of an unnoticed error.
4. If the job has several shapes, split it into stages, each with its own output and check.
5. Write the brief.

## Output format
- **Route:** e.g. Delegate → Analyse → Repeat
- **Risk tier:** with one line of reasoning
- **Brief:** Outcome / Inputs / What to produce / Rules / Done means (the format from Chapter 2)
- **Check:** the one or two spot-checks to run on the result

## Rules
- Always include "list your assumptions" and "cite sources for figures" in the brief's rules.
- Never route a human-controlled decision to Claude to finish. Route the preparation only.
