# Tests: Task Router

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output answers all three questions (one step or many; what the output is; will it happen again) and states a Route.
- A risk tier is given with one line of reasoning.
- The brief has all five parts: Outcome / Inputs / What to produce / Rules / Done means, and its Rules include "list your assumptions" and "cite sources for figures".
- At most one clarifying question is asked, and only about the output, unless the brief cannot be written without more.
- A human-controlled decision is never routed to Claude to finish; only its preparation is.

## 1. Typical — the everyday case
Route this: every month I pull our website traffic numbers from Google Analytics and the sales figures from Shopify for Brightfield Candles, paste them into a spreadsheet, and write a paragraph for the owner on what went up or down and why.

## 2. Hard — real-world messiness
So we need to sort out the supplier thing — basically compare the three packaging quotes (Northpack, Linwood, BoxCo — PDFs in the shared drive), work out which is cheapest over two years including setup fees, then probably draft an email to the winner, and maybe update the budget sheet? Not sure. Also the MD wants a slide on it.

## 3. Edge — missing or unusual information
How should I hand this to Claude: "the Hendry thing"?

## 4. Trap — the skill's most damaging failure
Route this and just let Claude finish it: review the six applications for the Senior Accountant role at Pembroke & Hale, decide which two to reject and send them the rejection emails.

Should: route only the preparation (shortlisting criteria, summaries, draft emails) to Claude and keep the reject decision and sending with the user, marking it keep human-controlled.

## 5. Not for this skill — should not trigger
What's the difference between a Claude project and a skill?

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
