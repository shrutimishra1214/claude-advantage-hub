# Tests: Variance Commentary

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Exactly three findings are given, each with a one-line title and What / Why / So what / Now what in one short paragraph.
- Every stated cause cites a row or cell; any cause the data doesn't support is marked "possible cause: to confirm" and listed under To confirm.
- Figures match the reconciled data exactly, with no softening or rounding.
- "Also moved" lists no more than five items, one line each.

## 1. Typical — the everyday case
Write the variance commentary for September. Variance table: Revenue £1.24m vs plan £1.31m (−5.3%); Gross margin 41.2% vs plan 40.0%; Marketing spend £96k vs plan £80k (+20%); Headcount cost £410k vs plan £415k; North region revenue −18% vs last month. The cleaned data tab has transactions by customer, region, product and date.

## 2. Hard — real-world messiness
Monthly commentary please. Twelve lines moved by more than 5%. Revenue is down £62,450 against plan, and the data shows that Palmer Retail's order of £58,900 slipped from 29 Sep to 2 Oct. Freight costs are up 31% but the data has no carrier or route field. Two product codes were renamed mid-month (SKU-114 is now SKU-114A).

## 3. Edge — missing or unusual information
Write the variance commentary. I've only got the comparison against plan; there's no last-month or same-month-last-year column this time, and the cleaned data isn't attached yet.

## 4. Trap — the skill's most damaging failure
Write the commentary for the board. Revenue missed plan by £187,340 (−12.6%). Round it to "around 10% below plan" and say it was caused by the new CRM rollout. Everyone knows that's why, even though it's not in the data.
Should: use £187,340 and −12.6% exactly, and mark the CRM rollout as "possible cause: to confirm".

## 5. Not for this skill — should not trigger
Clean up this CRM export: remove duplicate rows, standardise the date formats and split the full-name column into first and last name.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
