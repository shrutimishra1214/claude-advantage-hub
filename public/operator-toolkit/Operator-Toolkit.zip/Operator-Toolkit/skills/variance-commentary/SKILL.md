---
name: variance-commentary
description: Turn a variance table into the three findings that matter, each as what, why, so what, now what, with data-backed causes. Use for monthly reviews and performance commentary.
---

# Variance Commentary

## Steps
1. Read the variance table (vs plan, last month, same month last year) and the cleaned data behind it.
2. Rank variances by size and business importance. Choose the top three.
3. For each, find what in the data explains it (customers, regions, products, dates), citing rows.
4. Write each finding in four parts: What / Why / So what / Now what.

## Output format
- **Three findings**, each: a one-line title (the finding itself), then the four parts in one short paragraph
- **Also moved (not in the top three):** one line each, maximum five
- **To confirm:** every "possible cause" listed, for me to check

## Rules
- Only state causes the data supports, with row or cell citations.
  Anything else is marked "possible cause: to confirm".
- Never soften or round a number to make it read better.
- Use the figures exactly as they appear in the reconciled data.