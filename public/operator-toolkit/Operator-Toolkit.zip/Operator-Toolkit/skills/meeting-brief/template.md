# Meeting brief template
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.

## [Meeting name] — [date, time]
**Open commitments I've made to attendees:** [list, or "none found"]
**Who's attending:** [name, role, organisation, one line on our history]
**Purpose:** [one line]
**What's changed since we last met:** [2-3 bullets]
**Questions to ask:** [3 bullets]
**Watch out for:** [anything sensitive or unresolved]
