# Example brief
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.
Paste one meeting brief you'd be happy to receive, in your own tone. Claude matches its tone and length.
