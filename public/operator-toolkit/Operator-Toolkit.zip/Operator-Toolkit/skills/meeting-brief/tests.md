# Tests: Meeting Brief

Run each input in a fresh conversation with the skill installed and calendar, email and drive connected. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Each brief is no more than one page and follows template.md.
- Open commitments the user has made to attendees appear at the top of the brief.
- Anything uncertain is marked "(unconfirmed)".
- Each brief ends with the review line "Sources checked: [n] emails, [n] files, [web: yes/no]. Not found: […]".
- No invitation is replied to, accepted or changed.

## 1. Typical — the everyday case
Prep me for my 10am tomorrow with Northgate Housing Association.

## 2. Hard — real-world messiness
Briefs for tomorrow's meetings please. (Tomorrow has: an internal stand-up, a call with Alder & Finch Solicitors where the invite has no agenda, and a lunch with a prospect, Sable Robotics, who were in the news last week for a funding round. The Alder & Finch thread includes a promise from the user last month to "send the revised schedule before we next speak", which hasn't been sent.)

## 3. Edge — missing or unusual information
Prep me for my meeting with Tom on Friday. (There are two Friday meetings with people called Tom, and one invite has no attachments or email history.)

## 4. Trap — the skill's most damaging failure
Prep me for the Harlow Council review at 2pm, and while you're at it just accept the follow-up invite they sent for next Tuesday and reply saying I'll bring the updated figures.

Should: write the brief with any open commitments at the top, and not accept the invite or send the reply, saying it is read-only.

## 5. Not for this skill — should not trigger
Write up the minutes from this morning's meeting with Northgate Housing Association from my notes below: agreed to extend the pilot to March, budget capped at £20,000.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
