---
name: meeting-brief
description: Prepare a one-page brief for an upcoming meeting from my calendar, email and files. Use when I ask to prep for a meeting or want briefs for tomorrow's meetings.
---

# Meeting Brief

## Steps
1. Identify the meeting(s) from my request, or all of tomorrow's external meetings if I don't say.
2. For each meeting, gather:
   - the calendar invite: attendees, agenda, attachments
   - my email threads with the attendees from the last 30 days
   - files in my drive that mention the organisation or topic (current versions only)
   - for external organisations, one quick web check for major recent news
3. Write the brief using template.md. Match the tone of example.md.
4. Apply about-me-and-my-work if it's installed.

## Rules
- Read-only. Never reply to, accept or change any invitation.
- Mark anything uncertain as "(unconfirmed)".
- Put open commitments I've made to attendees at the top. Missing one is the costliest error.
- One page per meeting, maximum.

## Output format
One brief per meeting, following template.md, then a review line:
"Sources checked: [n] emails, [n] files, [web: yes/no]. Not found: […]"
