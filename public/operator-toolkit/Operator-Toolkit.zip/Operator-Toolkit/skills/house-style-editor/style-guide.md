# House style guide
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill. Keep it to one page.

## Spelling and grammar
- [e.g. British spelling: organise, colour, programme]
- [e.g. Sentence case for headings]

## Numbers, dates, currencies and percentages
- [e.g. Numbers one to nine in words, 10 and above in figures]
- [e.g. Dates as 30 September 2026]
- [e.g. £1.2m, not £1,200,000; 6%, not six per cent]

## Preferred and banned words
| Use | Don't use |
|---|---|
| [clients] | [customers] |
| [use] | [utilise] |

## Headings and lists
- [e.g. Every heading states its point: "Costs rose 6% because of freight", not "Costs"]
- [e.g. Bullets for lists of three or more; no full stops on short bullets]

## Tone for each main audience
- Leadership: [e.g. direct, evidence-first, recommendation in the first paragraph]
- Clients: [e.g. warm, plain English, no internal jargon]
- Team: [e.g. friendly, brief]

## This, not that
- This: "[Revenue was 6% below plan because two renewals slipped to October.]"
  Not that: "[Revenue performance was somewhat below expectations this period.]"
- This: "[Please approve by Friday.]"
  Not that: "[It would be great if we could look to get sign-off at some point soon.]"
