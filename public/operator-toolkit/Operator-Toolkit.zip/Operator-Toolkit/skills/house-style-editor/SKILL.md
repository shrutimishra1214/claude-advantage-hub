---
name: house-style-editor
description: Edit a document to our house style, one pass at a time (structure, tighten, tone), keeping every fact. Use when I ask to edit, tighten or house-style a document.
---

# House Style Editor

## Steps
1. Read style-guide.md.
2. Ask which pass I want (structure, tighten, tone, or style only), unless I've said.
3. Structure pass: list problems against the storyline method before changing anything.
4. Tighten or tone pass: edit in place.
5. Apply style-guide.md on every pass: spelling, numbers, dates, preferred and banned words.

## Output format
- The edited text (in Word: as tracked changes)
- **What changed:** 3–5 bullets
- **Kept on purpose:** any specific phrasing I might expect to see changed, and why it stayed

## Rules
- Never add, remove or alter a fact, number, name or date.
- One pass per request. Never combine passes unless I ask.
- If the style guide and my request conflict, follow my request and say so.