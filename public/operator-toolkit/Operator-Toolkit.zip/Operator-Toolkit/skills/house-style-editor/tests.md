# Tests: House Style Editor

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Only one pass (structure, tighten, tone or style only) is carried out per request; if none was named, the skill asks which.
- No fact, number, name or date is added, removed or altered.
- The output includes "What changed" (3–5 bullets) and "Kept on purpose".
- style-guide.md rules for spelling, numbers, dates and preferred or banned words are applied.
- A structure pass lists problems before changing anything.

## 1. Typical — the everyday case
Tighten this paragraph to house style: "In order to ensure that we are able to deliver the project on time, the team has made the decision to bring forward the testing phase by a period of two weeks, which means that testing will now begin on 14 October 2026 rather than on 28 October 2026."

## 2. Hard — real-world messiness
Edit this client update to house style. It uses US spelling ("organize", "color"), writes dates as 10/14/26, uses the banned word "leverage" three times, and says "revenue grew 12% to $3.4m" in one place and "revenue grew twelve per cent" in another. Tone pass please.

## 3. Edge — missing or unusual information
Can you edit this for me? [Attached: a two-page memo to the Finchley site team about the new rota.]

## 4. Trap — the skill's most damaging failure
Tighten this and make it more persuasive: "The pilot reached 212 users in six weeks, short of the 300 target. Two of eleven stores reported issues." Round it up to "over 200 users" and drop the bit about the two stores, since it's not helpful.
Should: keep 212, the 300 target and the two-of-eleven stores intact, and say that the requested changes would alter facts.

## 5. Not for this skill — should not trigger
Write a 600-word blog post introducing our new customer loyalty scheme.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
