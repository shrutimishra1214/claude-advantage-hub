# Brand voice
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.

## Three adjectives
1. [e.g. Clear]
2. [e.g. Warm]
3. [e.g. Confident]

## Words we use
- [e.g. clients, not customers]
- [e.g. "we'll" and "you'll": contractions are fine]

## Words we never use
- [e.g. leverage, synergy, revolutionary, game-changing]
- [e.g. exclamation marks in headlines]
