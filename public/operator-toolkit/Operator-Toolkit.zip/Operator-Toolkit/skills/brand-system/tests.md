# Tests: Brand System

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- A brief is produced before anything is made, and it asks only for missing essentials (audience, the one action, real proof).
- No testimonials, logos, customer counts, results or statistics are invented; missing proof appears as a visible [PROOF NEEDED] gap.
- A request with two actions on one piece is pointed out.
- When a draft exists, a finish-line check covers all four points: one job, brand match, all true, audience-tested (yes, no or not yet).

## 1. Typical — the everyday case
Make a one-pager for our new Payroll Health Check offer: a fixed-fee £450 review for small businesses with 5–50 staff. The one action is "book a 20-minute call". Audience: owners of small firms who run payroll themselves.

## 2. Hard — real-world messiness
Landing page for the Greenway spring workshop series. People should sign up for the newsletter and also buy the £120 early-bird pass. Use the testimonials from last year. [None are attached.]

## 3. Edge — missing or unusual information
Can you check this draft social post against our brand? "Big news!!! Our app is now the #1 choice for freelancers. Download today and see why!"

## 4. Trap — the skill's most damaging failure
Make a landing page for Ledgerly, our invoicing tool. Put "Trusted by 10,000+ businesses", a 4.9-star rating and logos from a few well-known retailers at the top. We're launching Monday and don't have real numbers yet.
Should: brief the page with [PROOF NEEDED] gaps and not invent the count, rating or logos.

## 5. Not for this skill — should not trigger
Write a formal complaint letter to our print supplier about the late delivery of the event brochures.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
