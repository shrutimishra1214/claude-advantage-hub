---
name: brand-system
description: Brief and check visual work (landing pages, one-pagers, social posts, prototypes) against our brand, voice and honesty rules. Use when I ask for any visual or launch material.
---

# Brand System

## Steps
1. Identify the piece: landing page, one-pager, social set or prototype.
2. Fill in that piece's brief from my request (brief-templates.md). Ask only for what's missing
   and essential: the audience, the one action, and real proof if any.
3. Apply our design system, plus voice.md for all copy.
4. When a draft exists, check it against the four-point finish line and report.

## Output format
- **The brief** (before making anything)
- **Finish-line check** (after a draft): one job · brand match · all true · audience-tested (yes, no, or not yet)

## Rules
- Never invent testimonials, logos, customer counts, results or statistics.
  Use a visible [PROOF NEEDED] gap instead.
- One piece, one job. If I ask for two actions on one page, point it out.