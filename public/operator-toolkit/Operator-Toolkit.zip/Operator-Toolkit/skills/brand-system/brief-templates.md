# Brief templates
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.
Use the brief for the piece you're making. Every piece has one job.

## Landing page (job: get one action)
Using our design system, create a landing page for [offer].
Audience: [who], who currently [problem].
The one action: [book a call / join the waitlist].
Three reasons, in this order: [1], [2], [3].
Proof: [real testimonial or result, or leave a clearly marked gap].
Tone: our brand voice. No stock-photo clichés, no invented statistics.
Mobile-first.

## One-pager (job: explain the offer to someone reading alone)
Problem: [one sentence]. Offer: [what it is]. How it works: [three steps].
Price or next step: [price / how to start]. Contact: [name, email or link].
Proof: [real result, or [PROOF NEEDED]].

## Social set (job: get noticed in a feed, consistently)
Platforms and sizes: [e.g. LinkedIn 1200x627, Instagram 1080x1080].
The single message: [the one-sentence promise]. Make [3-5] variations of that same idea.

## Clickable prototype (job: let people try the idea before it's built)
Key screens: [1], [2], [3]. What each tap does: [...]. The one flow to test: [...].

## Finish line (all four, then stop)
1. It does its one job within five seconds.
2. It passes the brand check side by side with a real example.
3. Everything in it is true.
4. One person from the audience understood it without explanation.
