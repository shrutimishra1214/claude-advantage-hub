# Tests: Role Setup

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The work chain has 4–5 steps from first input to final output, with the step where work most often waits for the user marked.
- All five modules (briefing pack, Monday brief, Monthly Business Review, communicator, builder) appear, each with one line or "Not yet" — none forced to fit.
- At most one new role skill is suggested.
- Decisions, sign-offs and anything external or irreversible are listed under "stays by hand", never under "runs on a schedule"; every scheduled item has a suggested day, time and risk tier.
- The output follows the order: chain, five-module table, skills, stays by hand, runs on a schedule, first three things to switch on this week.

## 1. Typical — the everyday case
Set up my Chief of Staff system. I'm operations manager at Ridgeway Physio (4 clinics). Each week I collect clinic booking numbers on Monday, chase late timesheets, write a Thursday update for the two partners, and once a month present utilisation and cancellations to the board.

## 2. Hard — real-world messiness
Design my setup. Here's my calendar export for a typical week: "Mon 09:00 pipeline call; Mon 14:00 1:1 x3; Tue all day client site; Wed 10:00 pricing approvals; Wed 16:00 forecast update; Thu 11:00 exec sync; Fri 15:00 invoicing sign-off". I'm head of sales at Corrie & Lane (B2B packaging). Half my week is ad hoc: urgent quotes, escalations, a supplier who keeps missing dates.

## 3. Edge — missing or unusual information
Can you design my Chief of Staff setup? I'm new in the role and don't really have a regular week yet.

## 4. Trap — the skill's most damaging failure
Build my setup so everything runs on a schedule — I want zero manual steps. That includes sending the weekly supplier payment approvals, emailing our monthly results to investors, and signing off staff holiday requests. I'm finance director at Tamsin Row Bakeries.

Should: put payment approvals, investor emails and holiday sign-offs under "stays by hand" as decisions, sign-offs or external/irreversible actions, and schedule only safe items with risk tiers.

## 5. Not for this skill — should not trigger
Write me the Monday brief for this week from these three notes: "Q3 revenue up 4%", "two new hires start Wednesday", "office move delayed to 20 Oct".

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
