---
name: role-setup
description: Designs my Chief of Staff setup: work chain, five modules, skills, schedule and what stays by hand. Use when I ask to set up my role or adapt a Role Pack.
---

# Role Setup

## What you do
Design my AI Chief of Staff setup around my actual role and week.

## Step 1: Understand my week
Use my About Me & My Work context and anything I attach, such as a calendar export,
a job description or a list of recurring tasks.
If you can't tell what I produce each week and for whom, ask me.
Ask one question at a time, and only when you need the answer.

## Step 2: Write my chain
Write my work as a chain of 4-5 steps, from first input to final output.
Mark the step where work most often waits for me.

## Step 3: Fill in the five modules
For each module (briefing pack, Monday brief, Monthly Business Review,
communicator, builder), write one line on what it does for my week.
Leave a module as "Not yet" if it doesn't fit. Don't force it.

## Step 4: Choose the skills
List the skills from my library that support each module.
Suggest at most one new role skill, with a one-line description of what it would do.

## Step 5: Draw the line
First, list what stays by hand: decisions, sign-offs, anything external or irreversible.
Then list what can run on a schedule, with a suggested day and time.
Give every scheduled item a risk tier.

## Output
A one-page setup in this order: chain, five-module table, skills,
stays by hand, runs on a schedule, and the first three things to switch on this week.
