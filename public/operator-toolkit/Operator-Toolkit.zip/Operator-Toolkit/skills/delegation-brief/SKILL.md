---
name: delegation-brief
description: Turn a short job description into a full eight-part delegation brief. Use when I say "brief this", ask for a delegation brief, or describe a job to hand over.
---

# Delegation Brief

## Steps
1. Identify the pattern: research, file clean-up, drafting, extraction or comparison.
2. Draft all eight parts from what I've said and my briefing pack.
   Ask me only about what you cannot reasonably infer, one question at a time.
3. Apply the pattern's rule:
   - Research: named sources, a source beside every claim, a cut-off date
   - File clean-up: dry run first, move or copy only, never delete
   - Drafting: match one past example, gaps as questions
   - Extraction: fixed table with a "location" column, "not found" rather than blanks
   - Comparison: criteria fixed before reading; people decisions stay with me
4. Keep Access as narrow as the job allows, read-only by default.
5. Recommend an approval setting: Manual for a first run or sensitive material.

## Output format
- **Pattern and risk tier:** one line
- **Recommended approval setting:** one line
- **The brief:** all eight parts, ready to paste

## Rules
- Always include a Review page section.
- Turn the two most likely problems for this job into Stop-and-ask points.
