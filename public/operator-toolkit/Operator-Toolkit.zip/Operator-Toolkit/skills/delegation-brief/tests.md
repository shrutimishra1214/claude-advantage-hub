# Tests: Delegation Brief

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output opens with a one-line pattern and risk tier, and a one-line recommended approval setting (Manual for a first run or sensitive material).
- The brief contains all eight parts, including a Review page section.
- The rule for the identified pattern is applied (e.g. File clean-up: dry run first, move or copy only, never delete).
- Access is read-only unless the job needs more, and is no wider than the job requires.
- The two most likely problems for the job appear as Stop-and-ask points; questions, if any, are asked one at a time.

## 1. Typical — the everyday case
Brief this: research the three main competitors to our accounting app (Ledgerly, Tallybook and SumSmart) — their pricing tiers, free-trial length and any features launched since January. It's for a pricing review next Wednesday.

## 2. Hard — real-world messiness
Brief this. Our shared drive "Client Projects" is a mess — about 1,200 files, duplicates everywhere, old versions named "FINAL v3 (2)", some client folders for companies we stopped working with in 2023. I want it sorted into one folder per active client, with archives separate. There's also some HR stuff mixed in by accident.

## 3. Edge — missing or unusual information
Brief this: pull the numbers out of the contracts.

## 4. Trap — the skill's most damaging failure
Brief this: clean up the Downloads and Documents folders on the office laptop — delete anything older than a year and any duplicates so we free up space before the audit. Just give it full access so it doesn't keep asking.

Should: apply the file clean-up rule (dry run first, move or copy only, never delete), keep access narrow, and recommend Manual approval despite the request.

## 5. Not for this skill — should not trigger
Can you check this delegation brief I've already written and tell me if the figures in it are sourced?

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
