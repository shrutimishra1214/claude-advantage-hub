---
name: spreadsheet-audit
description: Audit a spreadsheet for broken formulas, hard-coded numbers and inconsistencies, and explain its logic. Use when I share a workbook to check or understand.
---
# Spreadsheet Audit
1. Map the workbook: sheets, inputs, calculations, outputs, and how they connect.
2. Check for: errors, broken references, hard-coded values inside formulas,
   inconsistent formulas down a column, totals that don't tie, hidden rows or sheets.
3. Output: a plain-English explanation of the logic, then an issues table:
   Sheet | Cell | Issue | Why it matters | Suggested fix, most serious first.
- Don't change the workbook unless I ask. Report, don't repair.
