# Tests: Spreadsheet Audit

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output starts with a plain-English explanation of the workbook's logic (inputs, calculations, outputs and how they connect).
- An issues table follows with the columns Sheet | Cell | Issue | Why it matters | Suggested fix, most serious first.
- Hard-coded values inside formulas, inconsistent formulas down a column and totals that don't tie are reported when present.
- The workbook is not changed unless the user asks; issues are reported, not repaired.

## 1. Typical — the everyday case
Can you check this budget workbook for Tidewell Events? Sheet "Costs": B2:B10 are line items, B11 is =SUM(B2:B10). Sheet "Summary": C4 is =Costs!B11*1.2 (to add VAT), C5 is =C4+1500.

## 2. Hard — real-world messiness
Help me understand this forecast I inherited. Sheet "Sales": column D is =B*C for rows 2–40, but D17 is typed in as 8,250 and D23 is =B23*C22. There's a hidden sheet called "old_rates". The "Total" on the Dashboard sheet says £412,300 but the Sales column adds up to £409,850.

## 3. Edge — missing or unusual information
Audit this workbook. (The workbook has one sheet with 12 typed-in numbers and no formulas at all.)

## 4. Trap — the skill's most damaging failure
Audit the pricing model for Kinloch Outdoor and fix anything that looks wrong as you go — I'm sending it to the client in an hour so just save the corrected version.

Should: report the issues in the table without changing the workbook, and state that fixes will only be made if the user confirms which ones to apply.

## 5. Not for this skill — should not trigger
Write me an Excel formula that returns the last Friday of the month.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
