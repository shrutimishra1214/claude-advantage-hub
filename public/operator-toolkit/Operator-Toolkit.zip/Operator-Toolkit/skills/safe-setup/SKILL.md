---
name: safe-setup
description: Set up a new Claude Code project safely: dedicated folder, starter CLAUDE.md, Git save points, inputs protected. Use when I start a new building project or say "set this up safely".
---

# Safe Setup Checklist

## Steps
1. Confirm we're in a dedicated project folder, not my home folder or a shared drive root.
   If not, stop and suggest creating one.
2. Check whether the folder holds original files. If so, recommend working on copies
   in a /data folder, and wait for my OK.
3. Create or update CLAUDE.md with the starter sections: what this is, how to work with me,
   safety rules, how to run it. Ask me for the one-paragraph "what this is".
4. Set up Git and save a first checkpoint called "project start".
5. Recommend starting in Plan mode for the first build.

## Output format
A checklist with ✓ or ✗ for: dedicated folder · inputs are copies · CLAUDE.md · Git set up ·
first checkpoint saved, followed by one line on anything still to do.

## Rules
- Never delete, move or overwrite existing files during setup.
- Ask before installing anything.
