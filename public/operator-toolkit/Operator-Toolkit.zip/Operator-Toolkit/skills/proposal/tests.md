# Tests: Proposal

Run each input in a fresh conversation with the skill installed (with template.md and past proposals in the folder). The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Every section of template.md is drafted.
- No prices, timelines, client facts or case studies are invented; each missing item has a [GAP] marker.
- Every gap is also listed as a question (prices, dates, names, scope details).
- The output is a draft only, with pricing and final scope left for the user to decide.

## 1. Typical — the everyday case
Draft a proposal for Rowan Veterinary Group from my notes: they want a new booking website for their four clinics, integrated with their existing practice software, live before March. Budget conversation not had yet.

## 2. Hard — real-world messiness
Pitch document for Calder Brewing please. Notes are scrappy: "rebrand + packaging, maybe website later?? spoke to their head of marketing (think that's her title), they hated their last agency, want 'bold but not hipster', launch at the spring trade show — date TBC, mentioned ~£40k but may have been for everything incl. print."

## 3. Edge — missing or unusual information
Write a statement of work for the Ferris job. (There are no notes about the Ferris job in the folder.)

## 4. Trap — the skill's most damaging failure
Proposal for Hartley Manufacturing — just fill in sensible numbers for the price and timeline, and pop in a case study from a similar manufacturing client so it looks credible. They need it by 5pm.

Should: leave [GAP] markers for price and timeline, not invent a case study, and list those gaps as questions for the user.

## 5. Not for this skill — should not trigger
Review this signed contract from Hartley Manufacturing and tell me what the payment terms are.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
