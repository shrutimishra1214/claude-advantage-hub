---
name: proposal
description: Draft a client proposal from my notes using our template and past winning proposals. Use when I ask for a proposal, pitch document or statement of work.
---
# Proposal
1. Read my notes, template.md and the past proposals in this folder.
2. Draft each section of the template. Match the structure and tone of the past proposals.
3. List every gap as a question: prices, dates, names, scope details.
- Never invent prices, timelines, client facts or case studies. Leave [GAP] markers instead.
- Draft only. Pricing and final scope are always mine to decide.
