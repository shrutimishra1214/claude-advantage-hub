# Proposal template
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.

1. Summary: [the outcome for the client, in two sentences]
2. What we heard: [their situation and goals, in their words]
3. Our approach: [phases or steps]
4. Timeline: [GAP if not agreed]
5. Team: [who does what]
6. Investment: [GAP — pricing is always mine to decide]
7. Next steps: [one clear action]

Add two or three past proposals to this folder so Claude can match their structure and tone.
