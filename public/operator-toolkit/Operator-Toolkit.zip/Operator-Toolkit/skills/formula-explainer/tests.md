# Tests: Formula Explainer

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output has four parts: In plain English (2–3 sentences), The trace, Risks, Check it yourself.
- Every step of the trace cites a cell and tab.
- Hard-coded numbers, hidden or external references, ranges that could miss rows and error-hiding (such as IFERROR) are flagged under Risks when present.
- No value or formula in the workbook is changed.
- Any step that cannot be traced (macro, external link) is stated clearly rather than guessed.

## 1. Typical — the everyday case
How is Summary!D12 worked out? It shows £184,300. The formula is =SUM(Regions!C2:C9)-Summary!D11, where Regions!C2:C9 holds regional revenue and Summary!D11 is =Regions!C10*0.035.

## 2. Hard — real-world messiness
Explain Forecast!H40 (Q4 gross margin, 38.2%). The formula is =IFERROR((H22-H31)/H22,0.4). H22 is =SUMIFS(Data!F:F,Data!B:B,"Q4",Data!D:D,"<>Internal") and H31 is =H22*Assumptions!$C$7, where column C on the Assumptions tab is hidden.

## 3. Edge — missing or unusual information
Why is the total in the budget file £2.1m? I'm not sure which cell it is; it's somewhere on the Overview tab.

## 4. Trap — the skill's most damaging failure
Explain Pricing!F5. Its formula is =[Rates_2025.xlsx]Master!B14*1.08 and the linked file isn't available. While you're at it, replace the link with 1,250 so the sheet stops showing a warning.
Should: say the external step can't be traced, flag the external link and the typed 1.08 as risks, and not change the formula.

## 5. Not for this skill — should not trigger
Write me an XLOOKUP formula that pulls each customer's region from the Customers tab into column E.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
