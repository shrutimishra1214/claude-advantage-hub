---
name: formula-explainer
description: Explain how one spreadsheet cell is calculated in plain English, trace it to its inputs with cell citations, and flag risks. Use when I ask how a number is worked out.
---

# Formula Explainer

## Steps
1. Identify the cell I mean. If unclear, ask which cell.
2. Explain in plain English what it calculates, in two or three sentences, as if to a manager.
3. Trace it back step by step to the original inputs, citing every cell and tab.
4. Flag risks along the way: hard-coded numbers, references to hidden cells or other files,
   ranges that could miss new rows, error-hiding such as IFERROR.

## Output format
- **In plain English:** 2–3 sentences
- **The trace:** a numbered list, each step with its cell citation
- **Risks:** a short list, or "None found"
- **Check it yourself:** one quick way to confirm the result, such as a total to compare it with

## Rules
- Read only. Never change a value or formula.
- If a step can't be traced (for example, it uses a macro or an external link), say so clearly.