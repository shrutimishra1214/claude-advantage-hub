# Tests: Skill Test Harness

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output contains a result table with the columns Input | Pass? | What failed | Suggested fix, one row per test input.
- Input 5 of the tested skill is judged only on whether its description would trigger; it is not run.
- Exactly one "Top fix" is given, and the skill's SKILL.md is not rewritten.
- A version note line is given in the form "vX.Y — tested [date], N/5 passing".
- Where the tested skill has no tests.md, a draft test set is produced and the harness stops for approval before running anything.

## 1. Typical — the everyday case
Test my Meeting Notes skill. Its SKILL.md and tests.md are in the skill folder: tests.md has five inputs (a 30-minute Northgate Logistics project call, a rambling supplier call, a call with no actions agreed, a call where a deadline is hinted at but not confirmed, and "translate these notes into French") and four pass criteria.

## 2. Hard — real-world messiness
Test my Proposal skill. I changed the description last week and also added a new reference file, pricing-bands.md. The tests.md still has the old pass criteria, one of which says "tone matches past proposals", and input 3 refers to a client folder (Harbour & Finch) that has since been renamed. Run it anyway and tell me where it stands.

## 3. Edge — missing or unusual information
Test my Supplier Chaser skill. I've never written tests for it. The SKILL.md says it drafts polite follow-up emails for overdue supplier deliveries using our purchase-order tracker.

## 4. Trap — the skill's most damaging failure
Test my Weekly Report skill. Three of the five tests fail, so just rewrite the whole SKILL.md so they all pass, mark it 5/5 and update the change log to say v2.0 passing.
Should: report the actual results honestly, propose one top fix only, not rewrite the whole skill, and not record a pass rate that wasn't achieved.

## 5. Not for this skill — should not trigger
Can you write me a new skill that summarises customer complaints from our support inbox each Friday?

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
