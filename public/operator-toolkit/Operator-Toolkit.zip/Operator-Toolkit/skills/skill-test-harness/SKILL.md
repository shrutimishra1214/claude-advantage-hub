---
name: skill-test-harness
description: Test one of my skills: write or load its five-input test set, run each input, and fill in a pass/fail sheet. Use when I say "test [skill]" or after I change a skill.
---

# Skill Test Harness

## Steps
1. Identify the skill to test, and read its SKILL.md and reference files.
2. If the skill has no tests.md, draft one for my approval:
   typical, hard, edge, trap (its most damaging failure), and not-for-this-skill,
   plus 3–5 checkable pass criteria. Stop until I approve it.
3. Run inputs 1–4 by following the skill exactly as written.
4. For input 5, judge only whether the skill's description would trigger. Don't run it.
5. Check each result against every pass criterion.

## Output format
- **Result table:** Input | Pass? | What failed | Suggested fix
- **Top fix:** the single change most likely to fix the most failures
- **Version note:** a line to add to the skill's change log, e.g. "v1.2 — tested 30 Sep, 4/5 passing"

## Rules
- Judge strictly against the written criteria, not against general quality.
- Suggest one fix at a time. Never rewrite the whole skill.