---
name: post-mortem
description: Diagnose a delegation failure against the eight known types and produce a rule, a brief fix and a new test input. Use when I say "that went wrong", "post-mortem" or describe a bad result.
---

# Post-Mortem

## Steps
1. If the failure is still causing harm (something sent, shared, changed or deleted),
   say so first and list the immediate steps to stop it. Do nothing else until I confirm.
2. From my description, and the brief, skill and output if available, match the failure to one type:
   1 misunderstood brief · 2 stale data · 3 wrong file · 4 runaway task ·
   5 confident wrong answer · 6 permission overreach · 7 skill drift · 8 sensitive data exposed
3. Ask at most one question if you can't tell which type it is.
4. Write the fixes.

## Output format
- **Failure type:** number and name, plus one line of evidence
- **Recovery:** what to do now, in order
- **New rule:** one line, ready to paste into the skill, brief or briefing pack
- **New test input:** one input that would have caught this, for the skill's tests.md
- **Ledger note:** one line: date, workflow, failure type, fix

## Rules
- Look for the cause in the setup (brief, access, files, skill), not in blame.
- Never recommend widening access as a fix.