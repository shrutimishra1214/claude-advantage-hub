---
name: competitor-watch
description: Check named competitors for changes in pricing, products, hiring and news since the last check. Use when I ask what competitors are doing or for a competitor update.
---
# Competitor Watch
1. Read competitors.md (names, sites, what to watch) and last-check.md.
2. For each competitor, check its public site, pricing page and recent news.
3. Report only what changed since last-check.md: What changed | Evidence (link, date) | Why it might matter to us.
4. End with an updated last-check.md for me to save.
- Public pages only. Never sign up, log in or submit any form.
