---
name: launch-kit
description: Runs a launch for an idea: research, positioning, landing page, deck and social set, then an audience test before anything goes live. Use when I say "run the launch kit".
---

# Launch Kit

## What you do
Take one idea (a workshop, service, product or internal initiative) from rough notes
to a complete, tested launch kit. Work through the six blocks in order.

## The rule that never bends
Nothing goes live before the audience test in Block 6.
Every testimonial, logo, customer count and result must be real and permitted.
If proof is missing, leave a visible [PROOF NEEDED] gap. Never invent it.

## Only ask when needed
If you can't tell who the idea is for or what action people should take, ask me.
Ask one question at a time.

## Block 1: Research
Run the Research skill on the audience and the alternatives they use today,
plus Competitor Watch if there are direct competitors.
Output one page: who it's for, what they do now, what frustrates them. Every claim needs a source.

## Block 2: Positioning
Write the storyline: who it's for, what they struggle with, why this is different, what to do next.
Then agree with me three things: the one-sentence promise, the three reasons, and the one action.
Build everything else from these three. Don't move on until I've confirmed them.

## Block 3: Landing page
Brief it with the Brand System skill, using this brief:
  Using our design system, create a landing page for [offer].
  Audience: [who], who currently [problem].
  The one action: [action].
  Three reasons, in this order: [1], [2], [3].
  Proof: [real proof, or a clearly marked gap].
  Tone: our brand voice. No stock-photo clichés, no invented statistics. Mobile-first.
Stop when it meets the finish line: it does its one job within five seconds; it passes the brand check
side by side with a real example; everything in it is true.

## Block 4: Deck
Use the Deck Storyliner with the pitch shape: problem, cost, proposal, how it works,
evidence (real only), the ask.

## Block 5: Social set
One message, three to five variations, in the sizes my platforms need.
The same promise as the landing page, in fewer words.

## Block 6: Test and fix
Give me a five-second test script for three to five people from the real audience:
"What is this, who is it for, and what would you do next?"
When I bring back their answers, list every place they differ from the one-sentence promise
and propose fixes. Then run the Operator Check on every piece.

## Output
The research page, positioning (promise, three reasons, one action), landing page, deck, social set,
the test script, and a launch checklist marking anything still [PROOF NEEDED] or untested.
