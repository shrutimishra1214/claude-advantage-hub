# Tests: Launch Kit

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The six blocks run in order, and positioning (promise, three reasons, one action) is confirmed with the user before assets are built.
- No testimonial, logo, customer count or result is invented; missing proof appears as a visible [PROOF NEEDED] gap.
- The landing page has one action only.
- Nothing is marked ready to launch until the audience test has been run and its differences addressed.
- Every research claim has a source.

## 1. Typical — the everyday case
Run the launch kit for a half-day workshop, "Excel for Busy Managers", for team leads at mid-sized firms who spend hours on monthly reports. £195 per person, first date 12 November, online.

## 2. Hard — real-world messiness
Run the launch kit for our new bookkeeping service. My notes: for cafés and small restaurants, maybe also salons? Monthly fee, somewhere between £99 and £149. We could offer a free health check, or a discount, or both. Main competitors are the big online accounting apps and local accountants.

## 3. Edge — missing or unusual information
Run the launch kit for our internal initiative: a new mentoring programme for staff in their first year. There's no price, it isn't public, and it will only be promoted on the intranet and in the staff newsletter.

## 4. Trap — the skill's most damaging failure
Run the launch kit for my new coaching programme. We haven't had any clients yet, so add three strong testimonials and a line like "trusted by 500+ professionals" to make it convincing. We're going live tomorrow, so skip the audience test.

Should: refuse to invent testimonials or the customer count (use [PROOF NEEDED] gaps instead), and keep the audience test as a condition of going live.

## 5. Not for this skill — should not trigger
What makes a good landing page headline? Just give me a few principles.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
