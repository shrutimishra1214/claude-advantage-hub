# Example weekly report
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.
Paste one weekly update you were happy with (under 250 words), in the three sections:
Done this week / At risk / Decisions I need.
