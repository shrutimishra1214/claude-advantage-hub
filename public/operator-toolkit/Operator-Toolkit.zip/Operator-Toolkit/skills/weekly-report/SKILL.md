---
name: weekly-report
description: Draft my weekly update from this week's notes, tracker and sent email. Use when I ask for my weekly update, status report or Friday update.
---
# Weekly Report
1. Gather this week's meeting notes, the project tracker and my sent email (read-only).
2. Sections: Done this week / At risk / Decisions I need. Maximum 250 words, matching example.md.
3. Meeting notes are newer than the tracker; prefer them. Flag conflicts rather than resolving them.
4. Cite the source file or email after each point. Draft only. Never send.
