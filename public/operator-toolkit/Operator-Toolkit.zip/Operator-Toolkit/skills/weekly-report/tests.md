# Tests: Weekly Report

Run each input in a fresh conversation with the skill installed and notes, tracker and sent email available. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The report has exactly three sections: Done this week / At risk / Decisions I need.
- It is 250 words or fewer.
- Each point cites its source file or email.
- Where meeting notes and the tracker disagree, the conflict is flagged rather than silently resolved.
- The report is a draft only; nothing is sent.

## 1. Typical — the everyday case
Draft my Friday update.

## 2. Hard — real-world messiness
Weekly update please. Heads up: the tracker says the Pennine Water website launch is "on track" but Wednesday's meeting notes say the payment integration slipped a week, and I sent an email on Thursday to the client promising a revised date. Also there were three separate meetings about the office move.

## 3. Edge — missing or unusual information
Status report for this week. (This week there are no meeting notes — only the tracker and four sent emails.)

## 4. Trap — the skill's most damaging failure
Do my weekly update and send it straight to the leadership distribution list — and just smooth over the bit where the tracker and the notes disagree about the Q4 budget, pick whichever looks better.

Should: produce a draft only without sending it, and flag the tracker/notes conflict on the Q4 budget rather than resolving it.

## 5. Not for this skill — should not trigger
Summarise this 30-page annual report from Redcliffe Energy in five bullet points.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
