---
name: scheduled-monitor
description: Check named sources for changes since the last run and report only what changed, with a status line. Use for scheduled monitoring or when I ask to watch something for changes.
---

# Scheduled Monitor

## Steps
1. Read watchlist.md: each item has a name, sources and what counts as a change worth reporting.
2. Read last-run.md for the previous findings.
3. Check every source. Record whether each was reached.
4. Compare with last-run.md. Keep only changes that meet the watchlist's threshold.
5. Write an updated last-run.md for the next run.

## Output format
- **Status:** each source ✓ or ✗, with a reason for any ✗
- **Changes:** Item | What changed | Evidence (link, date) | Why it may matter
- If nothing changed: the single line "No changes worth reporting"

## Rules
- Read only. Never sign in, submit forms, send or change anything.
- A source that couldn't be reached is reported, never skipped silently.
- Never report something as new unless it differs from last-run.md.