# Watchlist
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.

| Item | Sources | What counts as a change worth reporting |
|---|---|---|
| [e.g. Competitor A pricing] | [https://.../pricing] | [any price or plan change] |
| [e.g. Regulation update] | [https://...] | [new guidance or consultation] |
