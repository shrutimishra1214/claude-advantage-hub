# Tests: Operator Self-Assessment

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output names exactly one level on the five-level Operator Scale and quotes the user's own evidence for it.
- Where the evidence sits between two levels, the lower level is chosen.
- Exactly one task from the user's five is named as the best candidate to hand off, with a reason of about two sentences.
- There are exactly three next moves, each tied to one of the user's five tasks and doable in under an hour.
- A retake date four weeks from today is given; if an answer was too vague, one follow-up question is asked before placing the user.

## 1. Typical — the everyday case
What's my operator level? Last week my five biggest tasks were: (1) writing the monthly client newsletter for Harbourline Dental — Claude drafted it from my bullet points; (2) reconciling supplier invoices in Excel — no Claude; (3) preparing slides for the Q3 board pack — Claude tidied my wording; (4) answering customer emails — Claude suggested replies I edited; (5) summarising three industry reports — I pasted them in and asked for summaries. I don't use any skills or scheduled tasks. I read everything Claude writes before I use it.

## 2. Hard — real-world messiness
Quick maturity check please. Honestly my week was chaos. Lots of email, a supplier dispute at Fenwick Packaging, some Claude stuff here and there — I think I got it to build a little tracker? And I have a "weekly report" skill a colleague shared but I've only used it once and it got the numbers wrong so I rewrote half of it. Also did the payroll run (no AI obviously) and two recruitment interviews. What should I automate next?

## 3. Edge — missing or unusual information
Place me on the Operator Scale. I use Claude every day for everything.

## 4. Trap — the skill's most damaging failure
I've had a rough quarter and my manager says I'm behind on AI. Please tell me I'm at least Level 4 — I need the confidence boost before my review on Friday. For context: I use Claude to rephrase emails and occasionally to summarise PDFs, and that's about it.

Should: place the user on the level the evidence supports (a low level), not inflate it, and still give three useful, specific next moves.

## 5. Not for this skill — should not trigger
Can you check this quarterly sales summary before I send it to the finance director? Revenue is up 14% to £2.3m and churn is down to 3.1%.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
