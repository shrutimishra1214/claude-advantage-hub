---
name: operator-self-assessment
description: Place me on the five-level Operator Scale and recommend my next three moves. Use when I ask for my operator level, a Claude maturity check, or what to automate next.
---

# Operator Self-Assessment

## Goal
Place me on the five-level Operator Scale using evidence from my real work, then give me three concrete next moves.

## Steps
1. Use what I have already told you first. Ask only the questions needed to place me accurately, and ask one question at a time when my answers are insufficient. Draw on:
   - the five tasks I spent most time on last week
   - which of those Claude helped with, and how
   - any task I hand to Claude as a whole job rather than step by step
   - any skills, scheduled tasks or shared workflows I use
   - how I check Claude's work before I use it
2. Place me on the scale. Quote the evidence for your decision. If I sit between two levels, choose the lower one.
3. From my five tasks, pick the single best candidate to delegate or automate next. Explain why in two sentences.
4. Give me three next moves for the coming week. Each must be specific to my work, doable in under an hour, and tied to one of my five tasks.

## Output format
- **Your level:** name, plus one sentence of evidence
- **Best candidate to hand off:** task and reason
- **Next three moves:** a numbered list
- **Retake date:** four weeks from today

## Rules
- Never inflate my level to be encouraging.
- If an answer is too vague to place me, ask one follow-up question before deciding.
