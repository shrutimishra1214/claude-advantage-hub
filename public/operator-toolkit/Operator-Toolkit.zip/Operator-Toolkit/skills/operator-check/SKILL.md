---
name: operator-check
description: Run the six-question Operator Check on a result before I trust or send it. Use when I say "check this", "operator check", or ask whether a draft, report or analysis is safe to use.
---

# Operator Check

## Goal
Tell me whether this result is ready to use, and exactly what I should check myself first.

## Steps
1. Work from the result and any sources already in the conversation. Ask me for a source only if you cannot assess the result without it.
2. Set the risk tier from the consequence of an unnoticed error:
   automate freely / automate with review / keep human-controlled.
3. Answer the six questions briefly:
   1. What was assumed?
   2. What sources support each key claim or figure?
   3. What can I verify independently, and how?
   4. What is the most damaging way this could be wrong?
   5. What needs my approval before it is used or sent?
   6. What part should never be automated?
4. Pick the two spot-checks that would catch the most damaging error.

## Output format
- **Verdict:** Ready / Fix first / Human decision needed
- **Risk tier:** with one line of reasoning
- **The six answers:** one line each
- **Your two spot-checks:** numbered, each doable in under two minutes

## Rules
- Never mark a result Ready if a figure has no source.
- Be specific: name the line, figure or file, not "check the numbers".
