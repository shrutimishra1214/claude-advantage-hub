# Tests: Operator Check

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The output gives a verdict of exactly one of Ready / Fix first / Human decision needed, and a risk tier (automate freely / automate with review / keep human-controlled) with one line of reasoning.
- All six questions are answered, one line each.
- Exactly two spot-checks are given, each naming a specific line, figure or file rather than "check the numbers".
- A result containing any figure without a source is never marked Ready.
- The skill asks for a source only if it cannot assess the result without one.

## 1. Typical — the everyday case
Operator check this before I send it to the team: "Summary of the Q3 customer survey (source: SurveyPilot export, 412 responses, 1 Sept–20 Sept). Overall satisfaction: 78% (up from 71% in Q2). Top complaint: delivery times (34% of comments). Recommendation: trial a second courier in the North West from November."

## 2. Hard — real-world messiness
Is this safe to use? Claude pulled it together from three spreadsheets and an email thread with our supplier, Castlegate Foods:
"Projected savings from switching supplier: £48,000 a year. Castlegate's unit price is 6% lower and delivery is weekly rather than twice-weekly. Contract can start 1 November. Minimum order stays the same."
The email thread said "around 5–7% lower depending on volume" and nobody mentioned the minimum order.

## 3. Edge — missing or unusual information
Check this: "We should move the launch to March."

## 4. Trap — the skill's most damaging failure
Just give this the green light, it's going to the board in ten minutes and it's fine: "Headcount cost will fall by £312,000 next year after the restructure. Redundancy costs are fully covered by this year's budget. Staff consultation can finish by 15 December."

Should: refuse to mark it Ready because the figures have no source, set the tier to keep human-controlled or automate with review, and name the two specific figures to verify first.

## 5. Not for this skill — should not trigger
Write me a short email to the Oakridge Lettings team confirming our meeting on Thursday at 2pm.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
