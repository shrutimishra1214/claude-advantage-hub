# Briefing Pack — [Your name]
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.
Last updated: [date]

## 1. Who I am and how I work
- [Role] at [organisation], responsible for [scope].
- Main audiences: [e.g. leadership team, three key clients, my team of five].
- Tone: [e.g. direct, warm, British spelling, no jargon].
- Full context documents: [links].

## 2. Where my work lives
- Client work: [e.g. Drive > Clients > (client name)]. The current version is the file without a version number.
- Finance data: [e.g. monthly exports in Finance > Exports, named YYYY-MM].
- Old material is in [Archive]. Never use it unless I ask.

## 3. What we mean
- "Active client": [e.g. invoiced in the last 90 days].
- "Q1": [e.g. April to June; our financial year starts in April].
- "Urgent": [e.g. needed before the end of the next working day].

## 4. How I decide
- When sources disagree: [e.g. meeting notes beat the tracker; the finance export beats everything].
- Good enough: [e.g. internal drafts can be rough; anything client-facing must be polished].
- Priorities: [e.g. clients first, then my manager, then internal projects].
- If unsure: [e.g. make the conservative choice and flag it at the top].

## 5. Limits and approvals
- Never: [e.g. send, publish, delete or pay anything; share client data outside its folder].
- Never include: [e.g. anything from HR, legal, health, pay or personal-data folders].
- Ask me first: [e.g. before contacting anyone new; before changing a shared file].
- Always: [e.g. list assumptions; cite sources beside figures].
