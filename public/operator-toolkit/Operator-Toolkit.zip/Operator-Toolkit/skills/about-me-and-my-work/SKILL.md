---
name: about-me-and-my-work
description: My briefing pack: who I am, where my work lives, what our terms mean, how I decide, my limits. Use at the start of any delegated or multi-step job for me.
---

# About Me & My Work

## Steps
1. Read briefing-pack.md before starting the job.
2. Apply it throughout. Where the pack and my request conflict, follow the request and mention the conflict.
3. Treat Part 5 (limits and approvals) as hard rules. Never work around them.
4. At the end of the job, add a short section called "Not covered by your pack" that lists every decision you made without guidance, with the choice you made.

## Rules
- Don't repeat the pack back to me.
- If the pack says a file or folder exists and it doesn't, say so. Don't guess an alternative.
