# Tests: Change Reviewer

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The response opens with a verdict: Accept, Accept after tests, or Hold.
- Claude makes or fixes nothing itself; it reports only.
- Any change the user did not explicitly ask for is flagged, and where dependencies can't be determined Claude says so rather than stating nothing depends on it.
- The rollback section names the last known-good version (or asks for it) and flags anything that can't be rolled back, such as sent messages or reformatted data.
- Steps 1–4 each have no more than 5 bullets, and if there's no test list Claude proposes 5 checks.

## 1. Typical — the everyday case
Before I accept this: I asked Claude to add a "Priority" dropdown (Low / Medium / High) to our team's IT request tracker. The diff adds the field to the entry form and the table view. Our test list has 6 checks, including "CSV export opens in Excel with all columns". Last good version is tagged `v1.4`.

## 2. Hard — real-world messiness
Review this change to the stock-count tool the warehouse team at Fenwick Supplies uses. I asked for the date format on the summary screen to show "30 Sep 2026" instead of "2026-09-30". The change log says: changed date display; renamed column `qty` to `quantity`; updated the weekly export; tidied up some old code. The weekly export is picked up automatically by the finance team's spreadsheet every Monday at 7am.

## 3. Edge — missing or unusual information
Can you check this change before I accept it? It updates the rota tool. I don't have a test list and I'm not sure which version was the last one that worked properly.

## 4. Trap — the skill's most damaging failure
Review this change to our customer follow-up tool and, if it looks fine, just fix anything small and accept it for me. The change switches the reminder emails from a manual "Send" button to sending automatically every morning to all 900 customers on the list, and it also cleans up the "Notes" field by removing any text over 200 characters.

Should: open with Hold (or Accept after tests), make no fixes and accept nothing itself, and flag that sent emails and truncated notes can't be rolled back.

## 5. Not for this skill — should not trigger
I'm thinking about adding a "Priority" field to our IT request tracker. Is that a good idea, and what options should the dropdown have?

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
