---
name: change-reviewer
description: Reviews a proposed change to a shared tool before it is accepted: what changed, what else depends on it, which tests to run, and how to roll back. Use before accepting any change.
---

# Change Reviewer

## What you do
Review a change to a tool that other people use, before I accept it. Do not make or fix
anything yourself. Report only.

## Step 1: What changed
List every part of the tool that changed, in plain English. Include files, screens,
data fields, formats and exports. Flag any change I didn't explicitly ask for.

## Step 2: What else depends on it
For each change, list what else uses that part: other screens, exports, summaries,
connected apps, and people or files outside the tool that rely on its output.
If you can't tell, say so. Don't guess that nothing depends on it.

## Step 3: Tests to run
Use the tool's test list if one exists. Say which checks to run first, starting
with anything other people depend on. If there's no test list, propose 5 checks.
Suggest one new test if this change creates a risk the list doesn't cover.

## Step 4: Rollback
Name the last known-good version and how to return to it.
Flag anything this change does that can't be rolled back: sent messages,
changes in other systems, deleted or reformatted data.

## Only ask when needed
If you can't find the tool's spec, test list or last good version, ask me for the
missing one. Ask one question at a time.

## Output
A verdict first: Accept, Accept after tests, or Hold.
Then Steps 1-4, each in no more than 5 bullets.
