---
name: assumption-checker
description: Find every assumption in a forecast or model, stated or hidden, and rate how well each is sourced and tested. Use when I ask to check a forecast or prepare to defend one.
---

# Assumption Checker

## Steps
1. List every stated assumption, from the assumption register or inputs tab.
2. Find hidden assumptions: typed numbers inside formulas, growth rates implied by
   formulas, date ranges, and anything carried over from a template.
3. For each assumption, rate:
   - Source: documented / partly documented / none
   - Evidence: back-tested / range checked / untested
   - Impact: how much year-end results move if it's wrong (high / medium / low)
4. Pick the three assumptions most likely to be challenged: high impact and weak evidence.

## Output format
- **Register check:** Assumption | Where | Source | Evidence | Impact | Note
- **Hidden assumptions:** list with cell citations, or "None found"
- **The three to prepare for:** each with the question you'll be asked, and what would answer it

## Rules
- Read only. Never change the model.
- A value without a source is rated "none", however reasonable it looks.