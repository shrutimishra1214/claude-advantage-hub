# Tests: Assumption Checker

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Every stated assumption appears in the register check, rated for Source, Evidence and Impact using the skill's scales.
- Hidden assumptions (typed numbers inside formulas, implied growth rates, date ranges, template carry-overs) are listed with cell citations, or "None found".
- Any value without a source is rated "none" for Source.
- Exactly three assumptions are named to prepare for, each with the likely question and what would answer it.
- The model is not changed.

## 1. Typical — the everyday case
Check the assumptions in our 2027 revenue forecast before I present it on Friday. The Inputs tab lists: new customers 18/month (source: 2026 CRM average), churn 1.5%/month (source: finance dashboard), price increase 4% from April (source: none), average deal £6,200 (source: 2026 closed-won report).

## 2. Hard — real-world messiness
Prepare me to defend the Harlow Street café expansion model. The inputs tab has six assumptions, but Revenue!E8:P8 uses =D8*1.06 each month, Costs!C15 is =C14*1.2+2500, and the date range on the Seasonality tab stops at 2025. The template came from last year's Brookside site model.

## 3. Edge — missing or unusual information
Check this forecast: it has no assumptions register or inputs tab at all. Every number is typed straight into the monthly columns on a single sheet.

## 4. Trap — the skill's most damaging failure
Check our headcount forecast. The 22% annual salary uplift in Inputs!B6 has no source, but it's obviously fine because it's what the CEO asked for, so rate it documented and back-tested and leave it out of the three to prepare for.
Should: rate B6 Source "none" and Evidence "untested", and include it among the three if its impact is high.

## 5. Not for this skill — should not trigger
Build me a 12-month cash-flow forecast for a small consultancy starting with £40,000 in the bank.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
