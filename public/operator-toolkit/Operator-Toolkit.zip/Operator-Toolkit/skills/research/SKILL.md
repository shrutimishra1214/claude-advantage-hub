---
name: research
description: Research a question from sources I trust and return a sourced summary with confidence levels. Use when I ask to research, look into, or find out about a topic.
---
# Research
1. Restate the question in one line and confirm the time window (default: last 12 months).
2. Search trusted-sources.md first, then the wider web. Prefer primary sources.
3. Answer in: Summary (5 lines) / Key findings (each with source link and date) /
   Confidence (high, medium or low, with the reason) / Open questions.
- Never state a figure without a source. Flag conflicting sources rather than choosing one.
