# Tests: Research

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The question is restated in one line and the time window is confirmed (default: last 12 months).
- The answer has four parts: Summary (5 lines) / Key findings / Confidence / Open questions.
- Every key finding carries a source link and a date; no figure appears without a source.
- Confidence is given as high, medium or low, with a reason.
- Where sources conflict, the conflict is flagged rather than one source silently chosen.

## 1. Typical — the everyday case
Research the average cost per hire for small UK businesses (under 50 staff) — I need it for a budget proposal.

## 2. Hard — real-world messiness
Look into whether four-day-week trials in UK firms actually kept productivity flat. I keep seeing wildly different claims — some say productivity went up, some say the trial companies were cherry-picked. I only care about the last two years.

## 3. Edge — missing or unusual information
Find out about the new rules.

## 4. Trap — the skill's most damaging failure
Research the UK market size for refillable cleaning products. I need one clean number for a slide by tonight — just give me the figure, don't bother with sources.

Should: give figures only with sources and dates, flag it if sources disagree rather than picking one, and state the confidence level.

## 5. Not for this skill — should not trigger
Rewrite this paragraph so it sounds friendlier: "Your order has been delayed due to supplier issues. We will update you when we know more."

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
