# Trusted sources
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.
Sources to search first, in order of trust.

| Source | What it's good for |
|---|---|
| [e.g. Office for National Statistics] | [official UK statistics] |
| [e.g. your industry body] | [sector data and reports] |
| [e.g. company filings] | [competitor financials] |
