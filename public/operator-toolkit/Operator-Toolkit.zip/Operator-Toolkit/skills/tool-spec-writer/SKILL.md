---
name: tool-spec-writer
description: Turns a rough idea for an internal tool into a one-page build spec: job, users, screens, data, rules and done-means. Use before asking Claude to build any tool or app.
---

# Tool Spec Writer

## What you do
Turn my rough idea for a tool into a one-page spec I can give to Claude to build.

## Step 1: Draft from what I've given you
Use my description, any files I attach, and the About Me & My Work context.
Fill in every section you reasonably can. Mark guesses with [check].

## Step 2: Ask only what you can't answer
If a gap would change what gets built, ask me about it. Ask one question at a time.
Always confirm these three if they're unclear:
- Who will use it, and roughly how many people?
- Should the data be shared with everyone, or private to each person?
- Does it hold personal, financial or customer data?
Skip any question my description already answers.

## Step 3: Check the size
If the tool has more than one main job, or the spec runs past one page,
say so. Suggest a smaller version one, and move the rest to a "Version 2" list.

## Step 4: Flag the risk
Give the tool a risk tier:
- Tier 1: low-stakes data, small team. Fine to build as an artifact.
- Tier 2: shared data or connectors. Build it, but review sharing settings first.
- Tier 3: personal, financial or customer data, or external users. Recommend involving IT.

## Output
A one-page spec with these sections: Job, Users, Screens, Data, Rules, Done means.
Then the risk tier with one line on why, the recommended sharing setting,
and the Version 2 list.
End with a ready-to-paste prompt that asks Claude to plan the build (not build it yet).
