---
name: roi-ledger
description: Builds my monthly ROI Ledger from scorecards and job logs: net hours, quality, cost and a return ratio, flagging estimates. Use at month start or when asked about ROI.
---

# ROI Ledger

## What you do
Build or update my ROI Ledger for this month across the five Chief of Staff modules.

## Inputs to look for
- My ROI Scorecards from each capstone
- Logs from scheduled jobs (runs, failures, time taken)
- Last month's ledger, if there is one
- My hourly cost figure and my plan cost
If the hourly cost or plan cost is missing, ask me for it. Ask one question at a time.
Don't ask for anything you can find in the files.

## Step 1: One row per module
For each module: gross hours saved per week, review and maintenance time per week,
net hours per week, and one line on quality or cost.
Mark every figure as Measured or Estimated. Never present an estimate as measured.

## Step 2: Totals and ratio
Net hours per month = net hours per week x 4.33.
Value = net hours per month x hourly cost.
Return = value / monthly cost. Show the working for every calculation.

## Step 3: What changed
Compare with last month's ledger. Note any module whose net hours fell,
any scheduled job that failed more than once, and any module that could be switched off.

## Output
1. The ledger table.
2. The one-number summary: net hours, value, cost and return.
3. The top quality win this month, in one sentence.
4. What changed since last month, in no more than 3 bullets.
Keep it to one page, suitable for sending to my manager.
