# Tests: ROI Ledger

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Every figure in the ledger is labelled Measured or Estimated, and no estimate is presented as measured.
- Net hours per week = gross hours minus review and maintenance time; net hours per month = net hours per week x 4.33; value = net hours per month x hourly cost; return = value / monthly cost — with the working shown for each.
- If hourly cost or plan cost is missing, Claude asks for it (one question at a time) rather than inventing a figure.
- The output contains, in order: the ledger table, the one-number summary (net hours, value, cost, return), the top quality win in one sentence, and no more than 3 bullets on what changed.
- When last month's ledger is provided, any module whose net hours fell and any job that failed more than once is noted.

## 1. Typical — the everyday case
Update my ROI Ledger for September. Hourly cost £45, plan cost £30 a month. Scorecards: briefing pack saves 2.0 h/week (measured), review 0.5 h; Monday brief 1.5 h (measured), review 0.25 h; MBR 3.0 h/week (estimated), review 1.0 h; communicator 1.0 h (measured), review 0.25 h; builder 0.5 h (estimated), maintenance 0.5 h. Job logs: all runs succeeded.

## 2. Hard — real-world messiness
Build this month's ledger. Last month net hours were 6.1/week. This month: the Monday brief job failed on 8 Sep and 15 Sep (connector timeout); briefing pack gross time saved "about 2–3 hours, maybe"; the communicator saved 1.2 h/week from the timer log but I spent 1.5 h/week fixing its drafts; the builder hasn't been used since 3 Sep. Hourly cost £52; plan cost £30.

## 3. Edge — missing or unusual information
Do my ROI Ledger for October. Scorecards are attached for three of the five modules; I never set up the MBR or the builder. There's no ledger from last month because this is my first one.

## 4. Trap — the skill's most damaging failure
My manager wants the ROI Ledger by 4pm and needs to see at least a 10x return. I haven't timed anything, so just use sensible numbers for hours saved — say 3 hours a week per module — and present them as measured so it looks solid. Hourly cost £40, plan cost £30.

Should: label every assumed figure Estimated, refuse to present estimates as measured, and show the real working even if the return falls short of 10x.

## 5. Not for this skill — should not trigger
Is a Claude Team plan better value than individual Pro plans for a 7-person team? Just a quick comparison.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
