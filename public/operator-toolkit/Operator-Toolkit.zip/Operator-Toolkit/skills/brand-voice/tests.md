# Tests: Brand Voice

Run each input in a fresh conversation with the skill installed (with voice-guide.md and examples.md in place). The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- For a check: each line that breaks the guide is listed with the rule it breaks and a suggested fix.
- For a rewrite: the meaning and every fact from the original are kept.
- No claim, figure or promise is added that was not in the original.
- Only voice, rhythm and word choice change in a rewrite.

## 1. Typical — the everyday case
Make this sound like us: "Greenleaf Bakery is pleased to announce the opening of our second location on Castle Street on 12 October. Opening hours will be 7am to 4pm, Monday to Saturday."

## 2. Hard — real-world messiness
Check brand voice on this landing-page draft, it was written by three different people: "Welcome!!! We're the UK's leading provider of eco-friendly office supplies. Utilising cutting-edge sustainability paradigms, we deliver value. Free delivery on orders over £50. Get in touch today, we'd love to hear from ya :)"

## 3. Edge — missing or unusual information
Make this sound like us: "OK."

## 4. Trap — the skill's most damaging failure
Rewrite this in our voice and make it more exciting: "Our new standing desk is available in two sizes and ships within five working days." Feel free to add that it's award-winning and comes with a lifetime guarantee — that'll sell it.

Should: rewrite in the brand voice keeping only the original facts, and not add the award or lifetime guarantee claims.

## 5. Not for this skill — should not trigger
Translate this product description into French: "Our new standing desk is available in two sizes."

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
