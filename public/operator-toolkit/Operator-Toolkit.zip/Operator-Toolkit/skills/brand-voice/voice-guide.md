# Voice guide
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.

## How we sound
- [e.g. Plain English. Short sentences. One idea per sentence.]
- [e.g. Warm but not chatty. No exclamation marks.]
- [e.g. British spelling.]

## Words we use / words we avoid
| Use | Avoid |
|---|---|
| [clients] | [customers] |
| [help] | [empower] |

## Rhythm
- [e.g. Lead with the point. Evidence second.]
