# Voice examples
> **Placeholder from the Operator Toolkit.** Replace everything below with your own content, then re-upload the skill.
Paste two or three short pieces of your best writing here: an email, a post, an introduction.
Label each with who it was for.

## Example 1: [audience]
[paste text]

## Example 2: [audience]
[paste text]
