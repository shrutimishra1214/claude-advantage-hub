---
name: brand-voice
description: Rewrite or check text in our brand voice using the guide and examples in this skill. Use when I ask to make something sound like us or check brand voice.
---
# Brand Voice
1. Read voice-guide.md and examples.md.
2. If asked to check: list each line that breaks the guide, with the rule it breaks and a fix.
3. If asked to rewrite: keep the meaning and every fact; change only voice, rhythm and word choice.
- Never add claims, figures or promises that weren't in the original.
