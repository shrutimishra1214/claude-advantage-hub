---
name: deck-storyliner
description: Turn material into a headline-title deck outline for my approval, then build slides only once I approve. Use when I ask for a deck, presentation or slides.
---

# Deck Storyliner

## Steps
1. Identify the deck type: leadership update, pitch or training. Ask only if unclear.
2. Write the outline using that type's shape:
   - one headline title per slide (a full sentence stating its point)
   - under each, the single piece of evidence that proves it
   - the answer or recommendation on slide 2
   - an appendix list for everything that didn't make the cut
3. STOP. Wait for my approval or changes.
4. When approved, build the slides in my template or design system, with native charts,
   and put the source of every figure in the slide notes.

## Output format (outline stage)
- Deck type and audience, in one line
- Numbered headline titles, each with its evidence line
- The "headline read-through": all titles as one paragraph, to show the argument flows

## Rules
- Never build slides before the outline is approved.
- Never invent results, quotes, logos or case studies. Leave a clearly marked [EVIDENCE NEEDED] gap.
- Maximum 8 main slides unless I say otherwise.