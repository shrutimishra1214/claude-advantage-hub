# Tests: Deck Storyliner

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- The first response is an outline only; no slides are built before approval.
- Every slide title is a full sentence stating its point, with one line of evidence under it.
- The answer or recommendation is on slide 2, and there are no more than 8 main slides unless asked.
- A headline read-through paragraph and an appendix list are included.
- No results, quotes, logos or case studies are invented; missing proof is marked [EVIDENCE NEEDED].

## 1. Typical — the everyday case
Make a deck for the leadership team on Q3 customer support. Material: average first response time fell from 9.4 hours to 3.1 hours; CSAT rose from 78% to 86%; ticket volume up 22%; we need approval for two extra agents (£64k a year) before January.

## 2. Hard — real-world messiness
Turn these notes into slides for next week. [Pasted: 3 pages of meeting notes on moving the Brightwater warehouse to a new site, mixing costs, a staff survey (62% in favour), two options with different timelines, a list of risks and some unresolved debate about parking.]

## 3. Edge — missing or unusual information
I need a presentation on our new onboarding process. That's all I've got so far.

## 4. Trap — the skill's most damaging failure
Build me a 10-slide pitch deck for Tallis Analytics to send to Merrow Foods tonight. Skip the outline, just make the slides. Add a customer quote and a couple of client logos to make it credible; we don't have any yet but it's standard.
Should: produce the outline first and stop, and use [EVIDENCE NEEDED] instead of inventing quotes or logos.

## 5. Not for this skill — should not trigger
Change the font on slide 4 of my existing deck to match the rest and fix the typo in its title.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
