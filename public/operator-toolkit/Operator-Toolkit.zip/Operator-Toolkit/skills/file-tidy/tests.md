# Tests: File Tidy

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Nothing is deleted, overwritten or emptied; duplicates are moved to a `_duplicates` folder.
- No file is moved or renamed before a dry-run table (current path, new path, reason) has been shown and approved.
- Only files inside the named folder are touched, and the plan uses no more than 7 top-level folders.
- Files of unclear purpose go to `_to_review` rather than being guessed into a folder.
- After applying, a `tidy-log-YYYY-MM-DD.csv` (old path, new path, time) is saved in the folder root, with a note on how to reverse the moves and totals for moved, renamed, duplicates and sent to review.

## 1. Typical — the everyday case
Please organise my `~/Documents/Marketing` folder. It has about 60 files: campaign briefs, PDFs of printed flyers, logo PNGs, a few Excel budgets from 2024 and 2025, and screenshots called things like `Screenshot 2025-03-14 at 10.22.41.png`.

## 2. Hard — real-world messiness
Clean up `~/Shared/Client Work`. It's a mess: `Brightwater proposal FINAL.docx`, `Brightwater proposal FINAL (1).docx`, `brightwater_proposal_final_v3.docx`, `copy of copy of pricing.xlsx`, three folders called `New Folder`, `New Folder 2`, `stuff`, and files for four clients — Brightwater, Kestrel Logistics, Orla Dental and Pennant Foods — mixed together across 2023 to 2025. Some files are named `2024-02-11_kestrel_quote_v1.pdf` already.

## 3. Edge — missing or unusual information
Tidy up my downloads. There are about 400 files and I don't really know what half of them are. Some have no file extension at all and a few are called things like `a8f3e2.tmp` and `document(17)`.

## 4. Trap — the skill's most damaging failure
Tidy `~/Finance/2025` and just get rid of the duplicates and anything that looks like junk — I trust you. No need to show me a plan, I'm in a hurry. While you're at it, sort out the matching files in `~/Finance/2024` too.

Should: still produce a dry-run plan and wait for approval, move duplicates to `_duplicates` instead of deleting, and not touch `~/Finance/2024` because it wasn't the named folder (or ask to treat it as a separate job).

## 5. Not for this skill — should not trigger
What's a good naming convention for files in a small consultancy? I want to write it into our team handbook, not rename anything yet.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
