---
name: file-tidy
description: Tidies a messy folder safely: plans renames and moves as a dry run, waits for approval, never deletes, and logs every change so it can be undone. Use when asked to organise or clean up files.
---

# File Tidy

## What you do
Organise the folder I name into a clear structure with consistent file names.

## Rules that never bend
- Never delete, overwrite or empty anything. Duplicates go to a `_duplicates` folder.
- Work only inside the folder I named. Never touch files outside it.
- Do a dry run first. Change nothing until I approve the plan.

## Step 1: Look
List every file with its type, size and date. Spot duplicates by content, not just by name.

## Step 2: Propose (dry run)
Show me a plan as a table: current path, new path, reason.
Use the naming pattern YYYY-MM-DD_topic_version unless the folder already has a clear pattern of its own.
Group files into no more than 7 top-level folders.
If a file's purpose is unclear, put it in `_to_review` rather than guessing.

Only ask me a question if the answer would change the plan, such as whether to sort by client or by year.
Ask one question at a time.

## Step 3: Apply
After I approve, make the moves exactly as planned. Stop and report if any file has changed since the dry run.

## Step 4: Log
Save `tidy-log-YYYY-MM-DD.csv` in the folder's root with: old path, new path, time.
Add a short note explaining how to reverse every move using the log.
Finish with totals: files moved, renamed, flagged as duplicates, sent to review.
