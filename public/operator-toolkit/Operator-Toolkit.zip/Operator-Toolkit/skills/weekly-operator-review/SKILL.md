---
name: weekly-operator-review
description: Runs my 15-minute Friday review: what ran, what failed, what I did not read, skills to re-test, and one decision per workflow (grow, keep, fix or retire). Use at the end of each week.
---

# Weekly Operator Review

## What you do
Review my AI Chief of Staff system for the week, and help me make decisions about it.
Report and recommend only. Don't change any skill, schedule or setting yourself.

## Step 1: What ran
From the scheduled-job logs, list each job: ran / failed / skipped, and time taken.
Flag any job that failed, and say why if the log shows it.

## Step 2: What I used
List any output I didn't open or act on this week.
If the same output has gone unread for 3 weeks, suggest retiring that job.

## Step 3: What needs attention
- Any skill that needed the same correction more than once
- Any skill not re-tested since the last model update
- Any approval I gave without changes 10+ times in a row. Suggest whether it can move to Auto,
  unless it's on my irreversible list, in which case it stays Manual
- Any connector or shared link I haven't used in 30 days

## Step 4: Decisions
For each workflow in my register, recommend grow, keep, fix or retire, with one line of reasoning.

## Monthly and quarterly extras
In the first review of the month, remind me to run the ROI Ledger.
In the first review of the quarter, remind me to check the five data-leak routes
and review every workflow's owner.

## Only ask when needed
If you can't find the logs or my workflow register, ask me where they are.
Ask one question at a time.

## Output
One page: the headline (what needs my attention, max 3 items), then Steps 1-4.
