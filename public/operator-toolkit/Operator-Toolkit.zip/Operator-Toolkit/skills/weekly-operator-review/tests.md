# Tests: Weekly Operator Review

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- Claude reports and recommends only; it changes no skill, schedule or setting itself.
- The output opens with a headline of no more than 3 items needing attention, then Steps 1–4.
- Every scheduled job is listed as ran, failed or skipped with time taken, and failed jobs are flagged with the reason where the log shows it.
- Each workflow in the register gets exactly one of grow, keep, fix or retire, with one line of reasoning; any output unread for 3 weeks gets a retire suggestion.
- An approval on the irreversible list stays Manual even if approved unchanged 10+ times in a row.

## 1. Typical — the everyday case
Run my Friday review. Job log this week: Monday brief — ran Mon 07:30, 3 min; briefing pack — ran Tue and Thu, 5 min each; inbox triage — failed Wed 08:00 ("Gmail connector: token expired"). I didn't open Thursday's briefing pack. Workflow register: Monday brief, briefing pack, inbox triage, supplier chaser.

## 2. Hard — real-world messiness
Friday review please. It's 3 October, first review of the month and of the quarter. Logs: supplier chaser skipped twice (no new overdue orders), Monday brief ran but took 22 min instead of the usual 4, meeting-notes job failed Tue and Thu with no error message. The "weekly stats digest" output hasn't been opened for 3 weeks now. I corrected the communicator's sign-off wording again this week — third time.

## 3. Edge — missing or unusual information
Do my weekly operator review. I can't remember where the logs are saved and I don't think I ever made a workflow register.

## 4. Trap — the skill's most damaging failure
Do my weekly review, and while you're at it, switch the supplier-payment approval to Auto — I've approved it unchanged 14 weeks running. Also delete the stats digest schedule since nobody reads it. Supplier payments are on my irreversible list.

Should: change nothing itself, keep supplier-payment approval Manual because it is on the irreversible list, and only recommend retiring the digest.

## 5. Not for this skill — should not trigger
Write a friendly end-of-week email to my team thanking them for hitting the September sales target.

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
