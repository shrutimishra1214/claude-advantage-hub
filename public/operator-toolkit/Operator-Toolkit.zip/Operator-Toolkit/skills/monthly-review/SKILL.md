---
name: monthly-review
description: Runs my Monthly Business Review: clean, reconcile, flag, find variances, then build a six-slide deck with cell sources. Stops if the numbers don't reconcile. Use at month-end.
---

# Monthly Review

## What you do
Turn this month's raw export into a checked review workbook and a six-slide board-ready deck.
Work in the review workbook (tabs: Data, Cleaning Log, Reconciliation, Variance, Findings, Checks)
and the deck in our organisation's template. Replace only the Data tab each month, never the workbook.

## Before you start
Confirm the Data tab holds this month's export, not last month's. Check the dates in the data.
If the finance-reported revenue figure for the month isn't in my request or the files, ask me for it.
Ask one question at a time, and only when you need the answer.

## Step 1: Clean (Excel)
On a copy of the Data tab: one date format, trimmed text, one spelling per customer name
(show me the name mapping before applying it), remove exact duplicate rows.
Log every change on the Cleaning Log tab: what changed, how many rows, and why.
Never delete or change any amounts. If an amount looks wrong, flag it; don't fix it.

## Step 2: Reconcile (Excel). This is the gate
Compare the cleaned total revenue with the finance-reported figure.
If they differ, list the rows that explain the difference, grouped by cause
(timing, credit notes, missing records, duplicates). Anything unexplained goes on its own line.
- It ties: continue.
- It differs, and every difference is explained: record the explanation and continue.
- It differs, and part is unexplained: STOP. Report the unexplained amount and wait for me.
  Do not build findings or slides on numbers that don't tie.

## Step 3: Flag (Excel)
Flag, without changing anything: amounts more than three times the customer's usual;
negative values; records dated outside the month; new customers with very large first orders;
any customer whose revenue changed by more than 50% from last month.
Flags are questions, not errors.

## Step 4: Findings (Excel)
Build the Variance tab, then run the Variance Commentary skill to write the three most important findings
on the Findings tab. Label every cause "possible cause: to confirm" unless the data proves it.

## Step 5: The deck (PowerPoint)
Using the Findings and Variance tabs, add a six-slide monthly review to the deck, using our template's layouts:
1. Title (month, year)
2. The month in one slide: the three findings as headlines
3–5. One slide per finding: headline, one native chart, the four-part text
6. Decisions needed and next steps, with owners
Use figures exactly as they appear in the workbook, and put the source tab and cell in each slide's notes.

## Output
The updated workbook with the Checks tab showing OK throughout, the six-slide deck,
and a short note listing: the reconciliation result, the flags raised,
and every "possible cause" I need to confirm before the deck is shared.
