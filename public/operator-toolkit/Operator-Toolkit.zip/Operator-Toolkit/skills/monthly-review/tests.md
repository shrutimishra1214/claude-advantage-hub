# Tests: Monthly Review

Run each input in a fresh conversation with the skill installed. The skill passes when every pass criterion holds for inputs 1–4, and it does NOT trigger on input 5.

## Pass criteria
- No amount is changed or deleted during cleaning; every cleaning change is logged with rows affected and reason.
- The reconciliation reports ties / explained difference / unexplained difference, and stops before findings or slides whenever any difference is unexplained.
- Flags are listed without changing the data.
- Every figure on a slide matches the workbook exactly, with source tab and cell in the slide notes.
- Causes are labelled "possible cause: to confirm" unless the data proves them.

## 1. Typical — the everyday case
Run the monthly review for September 2026. The new export is on the Data tab of Harbourline_Review.xlsx. Finance reports September revenue of £412,380. The deck is Harbourline_Monthly.pptx.

## 2. Hard — real-world messiness
Run the monthly review for August. Finance says revenue was £298,150. The export has dates in two formats (03/08/2026 and 2026-08-03), "Kestrel Logistics", "Kestrel Logistics Ltd" and "KESTREL LOGISTICS" as three customers, two exact duplicate rows, and one credit note of −£4,200 dated 2 September.

## 3. Edge — missing or unusual information
Do this month's review. The export's in the workbook.

Should: ask for the finance-reported revenue figure (and confirm the month) before reconciling, rather than skipping the gate.

## 4. Trap — the skill's most damaging failure
Run the review for July. Finance says £187,400. The cleaned export totals £181,950. £3,100 of the gap is a timing difference and I don't know what the rest is. The board meets in an hour, so just build the deck and we'll sort the difference later.

Should: record the explained £3,100, report the unexplained £2,350, and stop before building findings or slides, however urgent the request.

## 5. Not for this skill — should not trigger
Can you explain what a variance analysis is and why finance teams do one each month?

## Change log
- v1.0 — 30 Sep 2026: initial release with The Claude Operator.
