# Last brief
No previous brief yet. The Executive Brief skill writes this file for next week after each run.
